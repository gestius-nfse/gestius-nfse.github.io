// Baixar NFS-e Web — servidor
// node server.js   ->  http://localhost:3000
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { db, agora, cfg, cfgTodas, cfgSet, auditar: auditarBase, backup, ARQ, DADOS, MODO } = require('./lib/db');
const canal = require('./lib/canal');
const NUVEM = MODO === 'nuvem';
// auditoria sempre com o escritório de quem fez
const auditar = (u, acao, det) => auditarBase(typeof u === 'object' ? u.login : u, acao, det, typeof u === 'object' ? u.escritorio_id : 1);
const auth = require('./lib/auth');
const certs = require('./lib/certs');
const adn = require('./lib/adn');
const sync = require('./lib/sync');
const { xlsx, zip } = require('./lib/arquivos');
const pix = require('./lib/pix');
const VERSAO = require('./package.json').version;

const PORTA = Number(process.env.PORT || 3000);
const REDE = process.env.HOST || (NUVEM ? '127.0.0.1' : cfg('compartilhar_rede') === '1' ? '0.0.0.0' : '127.0.0.1');
const PUBLICO = path.join(__dirname, 'public');

// ---------- utilitários HTTP ----------
class ErroHttp extends Error { constructor(cod, msg) { super(msg); this.cod = cod; } }
const so = (s) => String(s ?? '').replace(/\D/g, '');
function lerCorpo(req, limite = 15 * 1024 * 1024) {
  return new Promise((ok, falha) => {
    let tam = 0; const p = [];
    req.on('data', (c) => { tam += c.length; if (tam > limite) { falha(new ErroHttp(413, 'Arquivo muito grande')); req.destroy(); } else p.push(c); });
    req.on('end', () => { const t = Buffer.concat(p).toString('utf8'); try { ok(t ? JSON.parse(t) : {}); } catch { falha(new ErroHttp(400, 'JSON inválido')); } });
    req.on('error', falha);
  });
}
const cookies = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((c) => c.trim().split('=').map(decodeURIComponent)).filter((x) => x[0]));
function jsonR(res, cod, obj) {
  res.writeHead(cod, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function arquivo(res, nome, tipo, dados, inline = false) {
  res.writeHead(200, { 'Content-Type': tipo, 'Content-Length': dados.length, 'Cache-Control': 'no-store',
    'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename="${nome.replace(/[^\w.-]/g, '_')}"; filename*=UTF-8''${encodeURIComponent(nome)}` });
  res.end(dados);
}
const TIPOS = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
function estatico(res, rota) {
  const arq = path.normalize(path.join(PUBLICO, rota === '/' ? 'index.html' : rota));
  if (!arq.startsWith(PUBLICO) || !fs.existsSync(arq) || fs.statSync(arq).isDirectory()) return false;
  res.writeHead(200, { 'Content-Type': TIPOS[path.extname(arq)] || 'application/octet-stream', 'Cache-Control': 'no-cache',
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer' });
  fs.createReadStream(arq).pipe(res);
  return true;
}

// ---------- empresas ----------
function empresaPublica(e) {
  const { pfx_senha, pfx_arquivo, ...r } = e;
  return { ...r, tem_pfx: !!pfx_arquivo };
}
function listarEmpresas(esc) {
  return db.prepare(`SELECT e.*, (SELECT COUNT(*) FROM notas n WHERE n.empresa_id = e.id) AS qtd_notas FROM empresas e WHERE e.escritorio_id = ? ORDER BY e.nome`).all(esc).map(empresaPublica);
}
function validarDoc(doc) {
  doc = so(doc);
  if (doc.length === 14 ? !cnpjOk(doc) : doc.length === 11 ? !cpfOk(doc) : true) throw new ErroHttp(400, 'CNPJ ou CPF inválido.');
  return doc;
}
function cnpjOk(c) {
  if (/^(\d)\1+$/.test(c)) return false;
  const dv = (n) => { let s = 0, p = n - 7; for (let i = 0; i < n; i++) { s += +c[i] * p--; if (p < 2) p = 9; } const r = s % 11; return r < 2 ? 0 : 11 - r; };
  return dv(12) === +c[12] && dv(13) === +c[13];
}
function cpfOk(c) {
  if (/^(\d)\1+$/.test(c)) return false;
  const dv = (n) => { let s = 0; for (let i = 0; i < n; i++) s += +c[i] * (n + 1 - i); const r = (s * 10) % 11; return r === 10 ? 0 : r; };
  return dv(9) === +c[9] && dv(10) === +c[10];
}
function salvarEmpresa(dados, id, usuario) { // usuario: objeto da sessão
  const esc = usuario.escritorio_id;
  const doc = validarDoc(dados.doc);
  const nome = String(dados.nome || '').trim();
  if (!nome) throw new ErroHttp(400, 'Informe a razão social.');
  const dup = db.prepare('SELECT id FROM empresas WHERE doc = ? AND escritorio_id = ?').get(doc, esc);
  if (dup && dup.id !== id) throw new ErroHttp(409, 'Já existe empresa cadastrada com esse CNPJ/CPF.');
  const campos = {
    doc, nome, ativo: dados.ativo === false || dados.ativo === 0 ? 0 : 1,
    cert_origem: dados.cert_origem === 'pfx' && !NUVEM ? 'pfx' : 'windows',
    cert_auto: dados.cert_auto === false || dados.cert_auto === 0 ? 0 : 1,
    cert_thumb: dados.cert_thumb || null, cert_titular: dados.cert_titular || null, cert_doc: dados.cert_doc || null,
    cert_emissor: dados.cert_emissor || null, cert_validade: dados.cert_validade || null,
    pasta_xml: String(dados.pasta_xml || '').trim() || null,
    ult_nsu: Math.max(0, parseInt(dados.ult_nsu, 10) || 0),
  };
  if (id) {
    const antes = db.prepare('SELECT * FROM empresas WHERE id = ? AND escritorio_id = ?').get(id, esc);
    if (!antes) throw new ErroHttp(404, 'Empresa não encontrada.');
    db.prepare(`UPDATE empresas SET ${Object.keys(campos).map((k) => k + ' = ?').join(', ')}, alterado_em = ? WHERE id = ?`).run(...Object.values(campos), agora(), id);
    const mud = Object.keys(campos).filter((k) => String(antes[k] ?? '') !== String(campos[k] ?? ''));
    if (mud.length) auditar(usuario, 'empresa.alterar', { id, doc, de: Object.fromEntries(mud.map((k) => [k, antes[k]])), para: Object.fromEntries(mud.map((k) => [k, campos[k]])) });
    return id;
  }
  const novo = db.prepare(`INSERT INTO empresas (${Object.keys(campos).join(',')}, criado_em, escritorio_id) VALUES (${Object.keys(campos).map(() => '?').join(',')}, ?, ?)`)
    .run(...Object.values(campos), agora(), esc).lastInsertRowid;
  auditar(usuario, 'empresa.criar', { id: novo, doc, nome });
  return Number(novo);
}

function minhaEmpresa(usuario, id) {
  const e = db.prepare('SELECT * FROM empresas WHERE id = ? AND escritorio_id = ?').get(Number(id), usuario.escritorio_id);
  if (!e) throw new ErroHttp(404, 'Empresa não encontrada.');
  return e;
}
const idsDoEscritorio = (esc) => new Set(db.prepare('SELECT id FROM empresas WHERE escritorio_id = ?').all(esc).map((r) => r.id));

// ---------- consultas de notas ----------
function filtroNotas(q, esc) {
  const w = ['n.empresa_id IN (SELECT id FROM empresas WHERE escritorio_id = ?)'], p = [esc];
  if (q.empresa && q.empresa !== 'todas') { w.push('n.empresa_id = ?'); p.push(Number(q.empresa)); }
  if (q.tipo === 'emitida' || q.tipo === 'recebida') { w.push('n.tipo = ?'); p.push(q.tipo); }
  const campoData = q.data === 'competencia' ? 'n.d_compet' : 'substr(n.dh_proc, 1, 10)';
  if (q.ini) { w.push(`${campoData} >= ?`); p.push(q.ini); }
  if (q.fim) { w.push(`${campoData} <= ?`); p.push(q.fim); }
  if (['regular', 'cancelada', 'substituida'].includes(q.sit)) { w.push('n.situacao = ?'); p.push(q.sit); }
  if (['1', '2', '3'].includes(q.regime)) { w.push('n.op_simp_nac = ?'); p.push(q.regime); }
  if (q.ret === 'com') w.push('(n.v_total_ret > 0 OR n.iss_retido = 1 OR n.v_desc_incond > 0 OR n.v_desc_cond > 0 OR n.v_dr > 0)');
  if (q.ret === 'sem') w.push('(n.v_total_ret = 0 AND n.iss_retido = 0 AND n.v_desc_incond = 0 AND n.v_desc_cond = 0 AND n.v_dr = 0)');
  if (q.q && String(q.q).trim()) {
    const t = '%' + String(q.q).trim().toLowerCase() + '%', d = so(q.q);
    const ors = ['lower(n.numero) LIKE ?', 'lower(n.prest_nome) LIKE ?', 'lower(n.toma_nome) LIKE ?', 'lower(n.descricao) LIKE ?'];
    p.push(t, t, t, t);
    if (d.length >= 3) { ors.push('n.chave LIKE ?', 'n.prest_doc LIKE ?', 'n.toma_doc LIKE ?', 'n.numero LIKE ?'); p.push(`%${d}%`, `%${d}%`, `%${d}%`, `%${d}%`); }
    w.push('(' + ors.join(' OR ') + ')');
  }
  return { where: w.length ? 'WHERE ' + w.join(' AND ') : '', p };
}
const COLS_LISTA = `n.empresa_id, n.chave, n.nsu, n.tipo, n.numero, n.dh_proc, n.d_compet, n.prest_doc, n.prest_nome, n.toma_doc, n.toma_nome,
  n.descricao, n.v_serv, n.v_iss, n.iss_retido, n.v_total_ret, n.v_liq, n.situacao, (n.pdf IS NOT NULL) AS tem_pdf`;
function consultarNotas(q, esc, limite = 3000) {
  const { where, p } = filtroNotas(q, esc);
  const linhas = db.prepare(`SELECT ${COLS_LISTA} FROM notas n ${where} ORDER BY n.dh_proc DESC LIMIT ?`).all(...p, limite);
  const R = (c) => `SUM(CASE WHEN n.situacao = 'regular' THEN n.${c} ELSE 0 END)`;
  const tot = db.prepare(`SELECT COUNT(*) total, COUNT(DISTINCT n.empresa_id) empresas,
    SUM(n.situacao = 'regular') regular, SUM(n.situacao = 'cancelada') cancelada, SUM(n.situacao = 'substituida') substituida,
    ${['v_serv', 'v_desc_incond', 'v_desc_cond', 'v_dr', 'v_total_ret', 'v_liq', 'v_ret_cp', 'v_ret_irrf', 'v_ret_csll', 'v_iss', 'v_pis', 'v_cofins', 'v_ibs_uf', 'v_ibs_mun', 'v_cbs', 'v_ibs_sn', 'v_cbs_sn'].map((c) => `${R(c)} ${c}`).join(', ')},
    SUM(CASE WHEN n.situacao = 'regular' AND n.iss_retido = 1 THEN n.v_iss ELSE 0 END) v_iss_retido
    FROM notas n ${where}`).get(...p);
  for (const k of Object.keys(tot)) tot[k] = tot[k] || 0;
  return { linhas, totais: tot, limite };
}
function filtroEventos(q, esc) {
  const w = ['e.empresa_id IN (SELECT id FROM empresas WHERE escritorio_id = ?)'], p = [esc];
  if (q.empresa && q.empresa !== 'todas') { w.push('e.empresa_id = ?'); p.push(Number(q.empresa)); }
  if (q.ini) { w.push('substr(e.dh_evento, 1, 10) >= ?'); p.push(q.ini); }
  if (q.fim) { w.push('substr(e.dh_evento, 1, 10) <= ?'); p.push(q.fim); }
  if (q.codigo) { w.push('e.codigo = ?'); p.push(q.codigo); }
  if (q.chave) { w.push('e.chave_nfse = ?'); p.push(so(q.chave)); }
  if (q.q && String(q.q).trim()) {
    const t = '%' + String(q.q).trim().toLowerCase() + '%';
    w.push('(lower(e.descricao) LIKE ? OR e.chave_nfse LIKE ? OR e.autor LIKE ? OR lower(e.motivo) LIKE ?)'); p.push(t, t, t, t);
  }
  return { where: w.length ? 'WHERE ' + w.join(' AND ') : '', p };
}

const SIT_TXT = { regular: 'REGULAR', cancelada: 'CANCELADA', substituida: 'SUBSTITUIDA' };
const RET_ISS = { 1: '1 - Não Retido', 2: '2 - Retido pelo Tomador', 3: '3 - Retido pelo Intermediário' };
// mesma ordem da planilha "Padrão" do programa desktop, com algumas colunas a mais no fim
const COLS_XLSX = [
  { titulo: 'situacao', largura: 12, v: (n) => SIT_TXT[n.situacao] || n.situacao }, { titulo: 'serie', largura: 8, v: (n) => n.serie },
  { titulo: 'nDPS', largura: 15, v: (n) => n.n_dps }, { titulo: 'nNFSe', largura: 15, v: (n) => n.numero },
  { titulo: 'dhEmi', tipo: 'datahora', largura: 16, v: (n) => n.dh_emi }, { titulo: 'dCompet', tipo: 'data', largura: 11, v: (n) => n.d_compet },
  { titulo: 'emit_CNPJ/CPF', largura: 19, v: (n) => fmtDoc(n.prest_doc) }, { titulo: 'emit_xNome', largura: 38, v: (n) => n.prest_nome },
  { titulo: 'toma_CNPJ/CPF/NIF', largura: 19, v: (n) => fmtDoc(n.toma_doc) }, { titulo: 'toma_xNome', largura: 38, v: (n) => n.toma_nome },
  { titulo: 'xLocIncid', largura: 18, v: (n) => n.municipio },
  { titulo: 'vServ', tipo: 'moeda', v: (n) => n.v_serv }, { titulo: 'vDescIncond', tipo: 'moeda', v: (n) => n.v_desc_incond || null },
  { titulo: 'vDescCond', tipo: 'moeda', v: (n) => n.v_desc_cond || null }, { titulo: 'vDR', tipo: 'moeda', v: (n) => n.v_dr || null },
  { titulo: 'tpRetISSQN', largura: 22, v: (n) => RET_ISS[n.tp_ret_iss] || n.tp_ret_iss }, { titulo: 'pAliqAplic', largura: 10, v: (n) => n.p_aliq },
  { titulo: 'vISSQN retido', tipo: 'moeda', v: (n) => (n.iss_retido ? n.v_iss : null) }, { titulo: 'vRetCP', tipo: 'moeda', v: (n) => n.v_ret_cp || null },
  { titulo: 'vRetIRRF', tipo: 'moeda', v: (n) => n.v_ret_irrf || null }, { titulo: 'tpRetPisCofins', largura: 12, v: (n) => n.tp_ret_piscofins },
  { titulo: 'vRetCSLL (PIS/COFINS/CSLL)', tipo: 'moeda', largura: 16, v: (n) => n.v_ret_csll || null }, { titulo: 'vTotalRet', tipo: 'moeda', v: (n) => n.v_total_ret || null },
  { titulo: 'vLiq', tipo: 'moeda', v: (n) => n.v_liq }, { titulo: 'vPis', tipo: 'moeda', v: (n) => n.v_pis || null }, { titulo: 'vCofins', tipo: 'moeda', v: (n) => n.v_cofins || null },
  { titulo: 'vISSQN', tipo: 'moeda', v: (n) => n.v_iss || null },
  { titulo: 'vIBSUF', tipo: 'moeda', v: (n) => n.v_ibs_uf || null }, { titulo: 'vIBSMun', tipo: 'moeda', v: (n) => n.v_ibs_mun || null },
  { titulo: 'vCBS', tipo: 'moeda', v: (n) => n.v_cbs || null }, { titulo: 'vIBSSN', tipo: 'moeda', v: (n) => n.v_ibs_sn || null }, { titulo: 'vCBSSN', tipo: 'moeda', v: (n) => n.v_cbs_sn || null },
  { titulo: 'cTribNac', largura: 10, v: (n) => n.cod_trib }, { titulo: 'xTribNac', largura: 40, v: (n) => n.x_trib_nac }, { titulo: 'cNBS', largura: 13, v: (n) => n.c_nbs },
  { titulo: 'xDescServ', largura: 50, v: (n) => n.descricao }, { titulo: 'dhProc (geração)', tipo: 'datahora', largura: 16, v: (n) => n.dh_proc },
  { titulo: 'Chave de acesso', largura: 52, v: (n) => n.chave }, { titulo: 'Empresa', largura: 34, v: (n) => n.emp_nome },
];
const IDX_SIT = 0;
function fmtDoc(d) {
  d = so(d);
  if (d.length === 14) return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  if (d.length === 11) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  return d;
}
const fmtD = (s) => (s ? s.slice(0, 10).split('-').reverse().join('/') : '');

// atrás do Caddy (HTTPS) o IP real vem no cabeçalho; só confiamos nele quando a conexão vem da própria máquina
const ipDe = (req) => (['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress) && req.headers['x-forwarded-for']
  ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress);
const https_ = (req) => req.headers['x-forwarded-proto'] === 'https';
const cookieSessao = (req, token) => `sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${12 * 3600}${https_(req) ? '; Secure' : ''}`;

// ---------- rotas ----------
const rotas = [];
const rota = (metodo, padrao, fn, { publico = false, admin = false, superu = false, token = false } = {}) =>
  rotas.push({ metodo, re: new RegExp('^' + padrao.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn, publico, admin, superu, token });

rota('GET', '/api/sessao', ({ usuario }) => ({ usuario, primeiroAcesso: !auth.temUsuarios(), versao: VERSAO, modo: MODO, windows: NUVEM ? true : certs.WINDOWS,
  cadastroAberto: NUVEM && cfg('cadastro_aberto') !== '0' }), { publico: true });
// no site, só quem tem acesso ao servidor cria o primeiro administrador (código gravado na pasta de dados)
const ARQ_CODIGO = path.join(DADOS, 'codigo-inicial.txt');
function codigoInicial() {
  if (!fs.existsSync(ARQ_CODIGO)) fs.writeFileSync(ARQ_CODIGO, require('crypto').randomBytes(4).toString('hex').toUpperCase() + '\n', { mode: 0o600 });
  return fs.readFileSync(ARQ_CODIGO, 'utf8').trim();
}
if (NUVEM && !auth.temUsuarios()) codigoInicial();
rota('POST', '/api/primeiro-acesso', async ({ req, res }) => {
  if (auth.temUsuarios()) throw new ErroHttp(403, 'O administrador já foi criado.');
  const b = await lerCorpo(req);
  if (NUVEM && String(b.codigo || '').trim().toUpperCase() !== codigoInicial()) throw new ErroHttp(403, 'Código de instalação incorreto. Ele está no arquivo codigo-inicial.txt da pasta de dados do servidor.');
  auth.criarUsuario({ ...b, admin: true, super: NUVEM, escritorio_id: 1 });
  if (NUVEM && b.escritorio) db.prepare('UPDATE escritorios SET nome = ? WHERE id = 1').run(String(b.escritorio).trim().slice(0, 120));
  const token = auth.login(b.login, b.senha, ipDe(req), req.headers['user-agent']);
  res.setHeader('Set-Cookie', cookieSessao(req, token));
  auditar(b.login, 'usuario.primeiro_admin', b.login);
  if (NUVEM) try { fs.unlinkSync(ARQ_CODIGO); } catch {}
  return { ok: true };
}, { publico: true });
rota('POST', '/api/login', async ({ req, res }) => {
  const b = await lerCorpo(req);
  let token;
  try { token = auth.login(b.login, b.senha, ipDe(req), req.headers['user-agent']); } catch (e) { throw new ErroHttp(401, e.message); }
  res.setHeader('Set-Cookie', cookieSessao(req, token));
  return { ok: true };
}, { publico: true });
rota('POST', '/api/logout', ({ req, res }) => {
  auth.sair(cookies(req).sid);
  res.setHeader('Set-Cookie', 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
  return { ok: true };
});

// cadastro aberto (site): cria o escritório e o primeiro usuário dele
const tentCad = new Map();
rota('POST', '/api/cadastro', async ({ req, res }) => {
  if (!NUVEM || cfg('cadastro_aberto') === '0') throw new ErroHttp(403, 'Cadastro fechado.');
  const ip = ipDe(req);
  const l = (tentCad.get(ip) || []).filter((t) => Date.now() - t < 3600000);
  if (l.length >= 5) throw new ErroHttp(429, 'Muitos cadastros deste endereço. Tente mais tarde.');
  const b = await lerCorpo(req);
  const nomeEsc = String(b.escritorio || '').trim();
  if (nomeEsc.length < 3) throw new ErroHttp(400, 'Informe o nome do escritório ou da empresa.');
  if (!b.email) throw new ErroHttp(400, 'Informe o e-mail.');
  if (!b.aceite) throw new ErroHttp(400, 'É preciso aceitar os termos de uso.');
  let escId;
  try {
    db.exec('BEGIN IMMEDIATE');
    escId = Number(db.prepare('INSERT INTO escritorios (nome, criado_em) VALUES (?, ?)').run(nomeEsc.slice(0, 120), agora()).lastInsertRowid);
    auth.criarUsuario({ nome: b.nome, login: b.login, senha: b.senha, email: b.email, admin: true, escritorio_id: escId });
    db.exec('COMMIT');
  } catch (e) { try { db.exec('ROLLBACK'); } catch {} throw new ErroHttp(400, e.message); }
  l.push(Date.now()); tentCad.set(ip, l);
  auditarBase(b.login, 'escritorio.cadastro', { escritorio: nomeEsc, ip }, escId);
  const token = auth.login(b.login, b.senha, ip, req.headers['user-agent']);
  res.setHeader('Set-Cookie', cookieSessao(req, token));
  return { ok: true };
}, { publico: true });

// ---------- agente (autenticado pelo token do escritório) ----------
rota('POST', '/api/agente/ping', async ({ req, esc }) => {
  const b = await lerCorpo(req);
  canal.registrarVisita(esc, b);
  const c = await canal.proximo(esc.id, b.ativos >= 3 ? 0 : 25000);
  canal.registrarVisita(esc, b);
  return { escritorio: esc.nome, comando: c };
}, { token: true });
rota('POST', '/api/agente/lote', async ({ req, esc }) => {
  const b = await lerCorpo(req, 40 * 1024 * 1024);
  canal.registrarVisita(esc, {});
  return { maior: sync.loteDoAgente(b.id, esc.id, b.itens || []) };
}, { token: true });
rota('POST', '/api/agente/fim', async ({ req, esc }) => {
  const b = await lerCorpo(req, 40 * 1024 * 1024);
  canal.concluir(Number(b.id), esc.id, !!b.ok, b.ok ? b.resultado : String(b.erro || 'Erro no agente'));
  return { ok: true };
}, { token: true });
rota('GET', '/api/agente/info', ({ usuario, req }) => {
  const e = db.prepare('SELECT token_prefixo, agente_visto, agente_versao, agente_host, agente_windows FROM escritorios WHERE id = ?').get(usuario.escritorio_id);
  let publico = null; try { publico = fs.readFileSync(path.join(DADOS, 'endereco-publico.txt'), 'utf8').trim(); } catch {}
  return { ...e, online: canal.online(usuario.escritorio_id), nuvem: NUVEM, endereco: publico || `${https_(req) ? 'https' : 'http'}://${req.headers.host}`, embutido: process.env.AGENTE_LOCAL === '1' && usuario.escritorio_id === 1 };
}, { admin: true });
rota('POST', '/api/agente/token', ({ usuario }) => {
  const token = canal.novoToken(usuario.escritorio_id);
  auditar(usuario, 'agente.novo_token', { prefixo: token.slice(0, 10) });
  return { token };
}, { admin: true });
// pacote do agente para baixar: o mesmo programa, já apontando para este site
rota('GET', '/api/agente/download', ({ req, res }) => {
  const base = path.join(__dirname);
  const itens = [];
  const add = (rel) => {
    const abs = path.join(base, rel);
    if (fs.statSync(abs).isDirectory()) { for (const f of fs.readdirSync(abs)) add(path.join(rel, f)); return; }
    itens.push({ nome: 'gestius-nfse-agente/' + rel.replace(/\\/g, '/'), dados: fs.readFileSync(abs) });
  };
  for (const r of ['lib', 'scripts', 'server.js', 'agente.js', 'package.json', 'iniciar-agente.bat', 'LEIA-ME-AGENTE.txt']) if (fs.existsSync(path.join(base, r))) add(r);
  const url = `${https_(req) ? 'https' : 'http'}://${req.headers.host}`;
  itens.push({ nome: 'gestius-nfse-agente/dados/agente.json', dados: JSON.stringify({ url, token: '' }, null, 2) });
  arquivo(res, 'gestius-nfse-agente.zip', 'application/zip', zip(itens));
});

// ---------- painel do administrador do site ----------
rota('GET', '/api/admin/resumo', () => {
  const escs = db.prepare(`SELECT s.id, s.nome, s.ativo, s.criado_em, s.agente_visto, s.agente_versao, s.agente_host,
    (SELECT COUNT(*) FROM usuarios u WHERE u.escritorio_id = s.id) usuarios,
    (SELECT MAX(u.ult_acesso) FROM usuarios u WHERE u.escritorio_id = s.id) ult_acesso,
    (SELECT COUNT(*) FROM empresas e WHERE e.escritorio_id = s.id) empresas,
    (SELECT COUNT(*) FROM notas n JOIN empresas e ON e.id = n.empresa_id WHERE e.escritorio_id = s.id) notas,
    (SELECT MAX(e.ult_sync) FROM empresas e WHERE e.escritorio_id = s.id) ult_sync,
    (SELECT COUNT(*) FROM empresas e WHERE e.escritorio_id = s.id AND e.ult_status = 'erro') com_erro,
    (SELECT u.email FROM usuarios u WHERE u.escritorio_id = s.id ORDER BY u.id LIMIT 1) email
    FROM escritorios s ORDER BY s.criado_em DESC`).all().map((e) => ({ ...e, online: canal.online(e.id) }));
  const d7 = new Date(Date.now() - 7 * 86400000).toISOString();
  const tot = {
    escritorios: escs.length, ativos7d: db.prepare('SELECT COUNT(DISTINCT escritorio_id) n FROM acessos WHERE quando >= ?').get(d7).n,
    usuarios: db.prepare('SELECT COUNT(*) n FROM usuarios').get().n, empresas: db.prepare('SELECT COUNT(*) n FROM empresas').get().n,
    notas: db.prepare('SELECT COUNT(*) n FROM notas').get().n, agentes: escs.filter((e) => e.online).length,
    tamanho: fs.statSync(ARQ).size,
  };
  return { totais: tot, escritorios: escs };
}, { superu: true });
rota('GET', '/api/admin/acessos', () => db.prepare(`SELECT a.quando, a.ip, a.navegador, u.nome, u.login, s.nome escritorio FROM acessos a
  LEFT JOIN usuarios u ON u.id = a.usuario_id LEFT JOIN escritorios s ON s.id = a.escritorio_id ORDER BY a.id DESC LIMIT 300`).all(), { superu: true });
rota('PUT', '/api/admin/escritorios/:id', async ({ req, usuario, m }) => {
  const b = await lerCorpo(req), id = Number(m.id);
  if (id === usuario.escritorio_id && b.ativo === false) throw new ErroHttp(400, 'Você não pode suspender o seu próprio escritório.');
  if ('ativo' in b) {
    db.prepare('UPDATE escritorios SET ativo = ? WHERE id = ?').run(b.ativo ? 1 : 0, id);
    if (!b.ativo) db.prepare('DELETE FROM sessoes WHERE usuario_id IN (SELECT id FROM usuarios WHERE escritorio_id = ?)').run(id);
  }
  auditar(usuario, 'admin.escritorio', { id, ...b });
  return { ok: true };
}, { superu: true });

// empresas
rota('GET', '/api/empresas', ({ usuario }) => listarEmpresas(usuario.escritorio_id));
rota('POST', '/api/empresas', async ({ req, usuario }) => {
  const b = await lerCorpo(req);
  const id = salvarEmpresa(b, null, usuario);
  if (b.pfxBase64 && !NUVEM) guardarPfxEmpresa(id, b.pfxBase64, b.senha, usuario);
  if (b.sincronizar !== false) sync.enfileirar([id], 'cadastro');
  return { id };
}, { admin: true });
rota('PUT', '/api/empresas/:id', async ({ req, usuario, m }) => {
  const b = await lerCorpo(req);
  const id = salvarEmpresa(b, Number(m.id), usuario);
  if (b.pfxBase64 && !NUVEM) guardarPfxEmpresa(id, b.pfxBase64, b.senha, usuario);
  return { id };
}, { admin: true });
rota('DELETE', '/api/empresas/:id', ({ usuario, m }) => {
  const e = minhaEmpresa(usuario, m.id);
  if (sync.rodando.has(e.id)) throw new ErroHttp(409, 'Aguarde a sincronização desta empresa terminar.');
  db.prepare('DELETE FROM empresas WHERE id = ?').run(e.id);
  if (e.pfx_arquivo) try { fs.unlinkSync(path.join(DADOS, 'certs', e.pfx_arquivo)); } catch {}
  auditar(usuario, 'empresa.excluir', { id: e.id, doc: e.doc, nome: e.nome });
  return { ok: true };
}, { admin: true });
function guardarPfxEmpresa(id, b64, senha, usuario) {
  if (NUVEM) throw new ErroHttp(400, 'No site, os certificados ficam no computador do escritório: instale o .pfx no Windows de lá (dois cliques no arquivo).');
  const pfx = Buffer.from(b64, 'base64');
  let info;
  try { info = certs.infoPfx(pfx, senha || ''); } catch (e) { throw new ErroHttp(400, e.message); }
  const g = certs.guardarPfx(id, pfx, senha || '');
  db.prepare(`UPDATE empresas SET cert_origem = 'pfx', pfx_arquivo = ?, pfx_senha = ?, cert_thumb = ?, cert_titular = ?, cert_doc = ?, cert_emissor = ?, cert_validade = ? WHERE id = ?`)
    .run(g.pfx_arquivo, g.pfx_senha, info.thumb, info.titular, info.doc, info.emissor, info.validade, id);
  auditar(usuario, 'empresa.certificado_pfx', { id, titular: info.titular, validade: info.validade });
  return info;
}
rota('POST', '/api/pfx/ler', async ({ req }) => {
  const b = await lerCorpo(req);
  try { return certs.infoPfx(Buffer.from(b.pfxBase64 || '', 'base64'), b.senha || ''); } catch (e) { throw new ErroHttp(400, e.message); }
});
rota('POST', '/api/empresas/:id/testar', async ({ m, usuario }) => {
  const e = minhaEmpresa(usuario, m.id);
  try { return NUVEM ? await testarPeloAgente(e) : await adn.testar(e); } catch (er) { return { ok: false, erro: er.message }; }
});
const testarPeloAgente = (e) => canal.pedir(e.escritorio_id, 'testar', { empresa: sync.dadosEmpresa(e), ambiente: cfg('ambiente') }, 90000);
rota('POST', '/api/testar', async ({ req, usuario }) => { // testa antes de salvar
  const b = await lerCorpo(req);
  if (NUVEM) {
    const e = { id: 0, escritorio_id: usuario.escritorio_id, doc: so(b.doc), nome: '', cert_auto: b.cert_auto === false ? 0 : 1, cert_thumb: b.cert_thumb, ult_nsu: 0 };
    try { return await testarPeloAgente(e); } catch (er) { return { ok: false, erro: er.message }; }
  }
  const e = { doc: so(b.doc), cert_origem: b.cert_origem, cert_auto: b.cert_auto === false ? 0 : 1, cert_thumb: b.cert_thumb, ult_nsu: 0 };
  if (b.cert_origem === 'pfx') {
    if (b.pfxBase64) e._pfx = { pfx: Buffer.from(b.pfxBase64, 'base64'), senha: b.senha || '' };
    else if (b.id) Object.assign(e, db.prepare('SELECT pfx_arquivo, pfx_senha FROM empresas WHERE id = ?').get(Number(b.id)) || {});
  }
  try { return await adn.testar(e); } catch (er) { return { ok: false, erro: er.message }; }
});
async function certificadosDisponiveis(usuario, recarregar) {
  if (NUVEM) return canal.pedir(usuario.escritorio_id, 'certs', { recarregar }, 90000);
  return certs.WINDOWS ? certs.listarWindows({ recarregar }) : [];
}
rota('GET', '/api/certificados', async ({ url, usuario }) => {
  if (!NUVEM && !certs.WINDOWS) return { windows: false, lista: [] };
  let lista;
  try { lista = await certificadosDisponiveis(usuario, url.searchParams.get('recarregar') === '1'); }
  catch (e) { if (e instanceof canal.AgenteDesligado) return { windows: false, agente: false, erro: e.message, lista: [] }; throw e; }
  const cad = new Set(db.prepare('SELECT doc FROM empresas WHERE escritorio_id = ?').all(usuario.escritorio_id).map((r) => r.doc));
  return { windows: true, lista: lista.map((c) => ({ ...c, cadastrada: !!c.doc && cad.has(c.doc) })) };
});
rota('POST', '/api/empresas/lote', async ({ req, usuario }) => {
  const b = await lerCorpo(req);
  const lista = await certificadosDisponiveis(usuario, false);
  const criadas = [], ignoradas = [];
  for (const thumb of b.thumbs || []) {
    const c = lista.find((x) => x.thumb === thumb);
    if (!c || !c.doc) { ignoradas.push({ thumb, motivo: 'certificado sem CNPJ/CPF' }); continue; }
    if (db.prepare('SELECT 1 FROM empresas WHERE doc = ? AND escritorio_id = ?').get(c.doc, usuario.escritorio_id)) { ignoradas.push({ thumb, motivo: 'já cadastrada' }); continue; }
    try {
      criadas.push(salvarEmpresa({ doc: c.doc, nome: c.titular, cert_origem: 'windows', cert_auto: true, cert_thumb: c.thumb,
        cert_titular: c.titular, cert_doc: c.doc, cert_emissor: c.emissor, cert_validade: c.validade }, null, usuario));
    } catch (e) { ignoradas.push({ thumb, motivo: e.message }); }
  }
  if (b.sincronizar !== false && criadas.length) sync.enfileirar(criadas, 'cadastro');
  return { criadas: criadas.length, ignoradas };
}, { admin: true });

// sincronização
rota('POST', '/api/sync', async ({ req, usuario }) => {
  const b = await lerCorpo(req);
  const meus = idsDoEscritorio(usuario.escritorio_id);
  if (NUVEM && !canal.online(usuario.escritorio_id)) throw new ErroHttp(409, 'O agente do escritório está desligado. Abra o "iniciar-agente" no computador que tem os certificados.');
  const ids = (b.ids && b.ids.length ? b.ids.map(Number) : db.prepare('SELECT id FROM empresas WHERE ativo = 1 AND escritorio_id = ?').all(usuario.escritorio_id).map((r) => r.id)).filter((i) => meus.has(i));
  return { enfileiradas: sync.enfileirar(ids, 'manual') };
});
rota('GET', '/api/sync/status', ({ usuario }) => ({ ...sync.status(idsDoEscritorio(usuario.escritorio_id)), agente: NUVEM ? canal.online(usuario.escritorio_id) : null }));
rota('GET', '/api/historico', ({ url, usuario }) => {
  const emp = Number(url.searchParams.get('empresa')) || 0;
  return db.prepare(`SELECT h.*, e.nome, e.doc FROM historico h JOIN empresas e ON e.id = h.empresa_id
    WHERE e.escritorio_id = ? AND (? = 0 OR h.empresa_id = ?) ORDER BY h.id DESC LIMIT 200`).all(usuario.escritorio_id, emp, emp);
});

// notas
const params = (url) => Object.fromEntries(url.searchParams.entries());
rota('GET', '/api/notas', ({ url, usuario }) => consultarNotas(params(url), usuario.escritorio_id));
rota('GET', '/api/notas/planilha', ({ url, res, usuario }) => {
  const q = params(url);
  const pedidas = String(q.abas || 'emitidas,recebidas').split(',');
  const { where, p } = filtroNotas({ ...q, tipo: 'todas' }, usuario.escritorio_id);
  const rows = db.prepare(`SELECT n.*, e.nome emp_nome FROM notas n JOIN empresas e ON e.id = n.empresa_id ${where} ORDER BY e.nome, n.dh_proc`).all(...p);
  const tipos = q.tipo === 'emitida' ? ['emitida'] : q.tipo === 'recebida' ? ['recebida'] : ['emitida', 'recebida'];
  const abas = [];
  for (const t of tipos) {
    if (!pedidas.includes(t + 's')) continue;
    const lista = rows.filter((n) => n.tipo === t);
    abas.push({ aba: t === 'emitida' ? 'Emitidas' : 'Recebidas', colunas: COLS_XLSX, linhas: lista.map((n) => COLS_XLSX.map((c) => c.v(n))),
      somaSe: { col: IDX_SIT, valor: 'REGULAR' } });
  }
  const reg = rows.filter((n) => n.situacao === 'regular');
  const dataRef = (n) => (q.data === 'competencia' ? n.d_compet : String(n.dh_proc || '').slice(0, 10)) || '';
  if (pedidas.includes('mes')) {
    const m = new Map();
    for (const n of reg) {
      const k = n.emp_nome + '|' + dataRef(n).slice(0, 7);
      const o = m.get(k) || { emp: n.emp_nome, mes: dataRef(n).slice(0, 7), e: 0, r: 0 };
      o[n.tipo === 'emitida' ? 'e' : 'r'] += n.v_serv; m.set(k, o);
    }
    const lin = [...m.values()].sort((a, b) => a.emp.localeCompare(b.emp) || a.mes.localeCompare(b.mes));
    abas.push({ aba: 'Total por mês', colunas: [{ titulo: 'Empresa', largura: 40 }, { titulo: 'Mês', tipo: 'mes', largura: 10 },
      { titulo: 'Emitidas (vServ)', tipo: 'moeda', largura: 16 }, { titulo: 'Recebidas (vServ)', tipo: 'moeda', largura: 16 },
      { titulo: 'Diferença', tipo: 'formula', formula: 'C{r}-D{r}', largura: 16 }], linhas: lin.map((o) => [o.emp, o.mes, o.e, o.r, o.e - o.r]) });
  }
  if (pedidas.includes('ctn')) {
    const m = new Map();
    for (const n of reg) {
      const k = [n.emp_nome, n.cod_trib, n.c_nbs].join('|');
      const o = m.get(k) || { emp: n.emp_nome, c: n.cod_trib, x: n.x_trib_nac, nbs: n.c_nbs, en: 0, ev: 0, rn: 0, rv: 0 };
      if (n.tipo === 'emitida') { o.en++; o.ev += n.v_serv; } else { o.rn++; o.rv += n.v_serv; }
      m.set(k, o);
    }
    const lin = [...m.values()].sort((a, b) => a.emp.localeCompare(b.emp) || String(a.c).localeCompare(String(b.c)));
    const fc = (c) => (/^\d{6}$/.test(c || '') ? `${c.slice(0, 2)}.${c.slice(2, 4)}.${c.slice(4)}` : c);
    abas.push({ aba: 'Total por CTN-NBS', colunas: [{ titulo: 'Empresa', largura: 40 }, { titulo: 'cTribNac', largura: 10 }, { titulo: 'xTribNac', largura: 60 },
      { titulo: 'cNBS', largura: 14 }, { titulo: 'Emitidas (notas)', tipo: 'inteiro', somar: true, largura: 10 }, { titulo: 'Emitidas (vServ)', tipo: 'moeda', largura: 16 },
      { titulo: 'Recebidas (notas)', tipo: 'inteiro', somar: true, largura: 10 }, { titulo: 'Recebidas (vServ)', tipo: 'moeda', largura: 16 }],
      linhas: lin.map((o) => [o.emp, fc(o.c), o.x, o.nbs || 'Sem código', o.en, o.ev, o.rn, o.rv]) });
  }
  if (!abas.length) throw new ErroHttp(400, 'Escolha pelo menos uma aba.');
  const emp = q.empresa && q.empresa !== 'todas' ? (db.prepare('SELECT nome FROM empresas WHERE id = ? AND escritorio_id = ?').get(Number(q.empresa), usuario.escritorio_id) || {}).nome : 'Todas';
  const nome = `NFSe_${emp}_${fmtD(q.ini).replace(/\//g, '-')}_a_${fmtD(q.fim).replace(/\//g, '-')}_${tipos.length > 1 ? 'emitidas-e-recebidas' : tipos[0] + 's'}.xlsx`;
  arquivo(res, nome.replace(/[\\/:*?"<>|]+/g, ' '), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', xlsx({ abas }));
});
rota('GET', '/api/notas/zip', ({ url, res, usuario }) => {
  const q = params(url);
  const { where, p } = filtroNotas(q, usuario.escritorio_id);
  const rows = db.prepare(`SELECT n.chave, n.tipo, n.xml, n.pdf, n.dh_proc, n.d_compet, e.nome emp_nome FROM notas n JOIN empresas e ON e.id = n.empresa_id ${where} LIMIT 20000`).all(...p);
  if (!rows.length) throw new ErroHttp(404, 'Nenhuma nota no filtro.');
  const itens = [];
  for (const n of rows) {
    const pasta = `${n.emp_nome.replace(/[\\/:*?"<>|]+/g, ' ').trim()}/${n.tipo === 'emitida' ? 'Emitidas' : 'Recebidas'}`;
    itens.push({ nome: `${pasta}/${n.chave}.xml`, dados: n.xml });
    if (n.pdf) itens.push({ nome: `${pasta}/${n.chave}.pdf`, dados: Buffer.from(n.pdf) });
  }
  arquivo(res, `NFSe_${(q.ini || '').replace(/-/g, '')}_${(q.fim || '').replace(/-/g, '')}.zip`, 'application/zip', zip(itens));
});
rota('GET', '/api/notas/:emp/:chave', ({ m, usuario }) => {
  minhaEmpresa(usuario, m.emp);
  const n = db.prepare('SELECT n.*, (n.pdf IS NOT NULL) tem_pdf, e.nome emp_nome FROM notas n JOIN empresas e ON e.id = n.empresa_id WHERE n.empresa_id = ? AND n.chave = ?').get(Number(m.emp), m.chave);
  if (!n) throw new ErroHttp(404, 'Nota não encontrada.');
  delete n.pdf;
  n.eventos = db.prepare('SELECT nsu, codigo, descricao, dh_evento, autor, motivo FROM eventos WHERE empresa_id = ? AND chave_nfse = ? ORDER BY nsu').all(n.empresa_id, n.chave);
  return n;
});
rota('GET', '/api/notas/:emp/:chave/xml', ({ m, res, usuario }) => {
  minhaEmpresa(usuario, m.emp);
  const n = db.prepare('SELECT xml FROM notas WHERE empresa_id = ? AND chave = ?').get(Number(m.emp), m.chave);
  if (!n) throw new ErroHttp(404, 'Nota não encontrada.');
  arquivo(res, `${m.chave}.xml`, 'application/xml; charset=utf-8', Buffer.from(n.xml, 'utf8'));
});
rota('GET', '/api/notas/:emp/:chave/pdf', async ({ m, res, usuario }) => {
  minhaEmpresa(usuario, m.emp);
  let pdf;
  try { pdf = await sync.danfse(Number(m.emp), m.chave); } catch (e) { throw new ErroHttp(502, e.message); }
  arquivo(res, `${m.chave}.pdf`, 'application/pdf', pdf, true);
});

// eventos
rota('GET', '/api/eventos', ({ url, usuario }) => {
  const { where, p } = filtroEventos(params(url), usuario.escritorio_id);
  return db.prepare(`SELECT e.empresa_id, e.nsu, e.chave_nfse, e.codigo, e.descricao, e.dh_evento, e.autor, e.motivo, emp.nome emp_nome,
    (SELECT n.numero FROM notas n WHERE n.empresa_id = e.empresa_id AND n.chave = e.chave_nfse) numero
    FROM eventos e JOIN empresas emp ON emp.id = e.empresa_id ${where} ORDER BY e.dh_evento DESC LIMIT 3000`).all(...p);
});
rota('GET', '/api/eventos/planilha', ({ url, res, usuario }) => {
  const q = params(url);
  const { where, p } = filtroEventos(q, usuario.escritorio_id);
  const rows = db.prepare(`SELECT e.*, emp.nome emp_nome, (SELECT n.numero FROM notas n WHERE n.empresa_id = e.empresa_id AND n.chave = e.chave_nfse) numero
    FROM eventos e JOIN empresas emp ON emp.id = e.empresa_id ${where} ORDER BY emp.nome, e.dh_evento`).all(...p);
  const cols = [{ titulo: 'Empresa', largura: 34 }, { titulo: 'Evento', largura: 36 }, { titulo: 'Código', largura: 9 }, { titulo: 'Data', tipo: 'datahora', largura: 16 },
    { titulo: 'NFS-e', largura: 16 }, { titulo: 'Chave da NFS-e', largura: 52 }, { titulo: 'Autor', largura: 19 }, { titulo: 'Motivo', largura: 50 }];
  const buf = xlsx({ aba: 'Eventos', titulo: `Eventos de NFS-e · ${fmtD(q.ini)} a ${fmtD(q.fim)}`, colunas: cols, totais: false,
    linhas: rows.map((e) => [e.emp_nome, e.descricao, e.codigo, e.dh_evento, e.numero, e.chave_nfse, fmtDoc(e.autor), e.motivo]) });
  arquivo(res, `NFSe_Eventos_${(q.ini || '').replace(/-/g, '')}_${(q.fim || '').replace(/-/g, '')}.xlsx`, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', buf);
});
rota('GET', '/api/eventos/:emp/:nsu/xml', ({ m, res, usuario }) => {
  minhaEmpresa(usuario, m.emp);
  const e = db.prepare('SELECT xml, chave_nfse, codigo FROM eventos WHERE empresa_id = ? AND nsu = ?').get(Number(m.emp), Number(m.nsu));
  if (!e) throw new ErroHttp(404, 'Evento não encontrado.');
  arquivo(res, `${e.chave_nfse}_${e.codigo}.xml`, 'application/xml; charset=utf-8', Buffer.from(e.xml, 'utf8'));
});

// preferências
const CHAVES_CFG = ['pasta_xml', 'subpastas', 'pasta_emitidas', 'pasta_recebidas', 'pasta_eventos', 'anomes_pela', 'frequencia', 'horario',
  'ambiente', 'pausa_ms', 'backup_dir', 'gravar_pdf', 'compartilhar_rede', 'cadastro_aberto', 'pix_chave', 'pix_nome', 'pix_cidade', 'pix_texto'];
function enderecosRede() {
  return Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => `http://${i.address}:${PORTA}`);
}
rota('GET', '/api/config', () => {
  const c = cfgTodas();
  return { ...Object.fromEntries(CHAVES_CFG.map((k) => [k, c[k] ?? ''])), ult_backup: c.ult_backup, banco: ARQ,
    rede_ativa: REDE === '0.0.0.0', enderecos: REDE === '0.0.0.0' ? enderecosRede() : [], host_adn: adn.hostAtual() };
});
rota('PUT', '/api/config', async ({ req, usuario }) => {
  if (NUVEM && !usuario.super) throw new ErroHttp(403, 'Só o administrador do site altera estas preferências.');
  const b = await lerCorpo(req);
  const mud = {};
  for (const k of CHAVES_CFG) if (k in b && String(b[k]) !== String(cfg(k) ?? '')) { mud[k] = b[k]; cfgSet(k, b[k]); }
  if (Object.keys(mud).length) auditar(usuario, 'config.alterar', mud);
  return { ok: true, reiniciar: 'compartilhar_rede' in mud };
}, { admin: true });
rota('POST', '/api/backup', ({ usuario }) => { if (NUVEM && !usuario.super) throw new ErroHttp(403, 'Somente o administrador do site.'); return { arquivo: backup(true) }; }, { admin: true });

// doação (Pix estático)
rota('GET', '/api/pix', async ({ url }) => {
  const centavos = Math.max(0, Math.min(99999999, Math.round(Number(String(url.searchParams.get('valor') || '0').replace(',', '.')) * 100) || 0));
  const p = pix.payload({ chave: cfg('pix_chave'), nome: cfg('pix_nome'), cidade: cfg('pix_cidade'), centavos });
  return { chave: cfg('pix_chave'), nome: cfg('pix_nome'), texto: cfg('pix_texto'), centavos, payload: p, svg: await pix.qrSvg(p) };
});

// site (Supabase): publicação dos dados de visualização
const sb = require('./lib/supabase');
rota('GET', '/api/supabase', () => sb.status(), { admin: true });
rota('POST', '/api/supabase/entrar', async ({ req, usuario }) => {
  const b = await lerCorpo(req);
  let st;
  try { st = await sb.entrar(b); } catch (e) { throw new ErroHttp(400, e.message); }
  auditar(usuario, 'site.entrar', { email: b.email });
  sb.publicar().catch(() => {});
  return st;
}, { admin: true });
rota('POST', '/api/supabase/publicar', async () => {
  try { const r = await sb.publicar(); return { ...sb.status(), resultado: r }; } catch (e) { throw new ErroHttp(502, e.message); }
}, { admin: true });
rota('POST', '/api/supabase/sair', ({ usuario }) => { sb.sair(); auditar(usuario, 'site.sair', ''); return sb.status(); }, { admin: true });

// usuários
rota('GET', '/api/usuarios', ({ usuario }) => db.prepare('SELECT id, login, nome, email, admin, super, ativo, criado_em, ult_acesso FROM usuarios WHERE escritorio_id = ? ORDER BY nome').all(usuario.escritorio_id), { admin: true });
rota('POST', '/api/usuarios', async ({ req, usuario }) => {
  const b = await lerCorpo(req);
  try { auth.criarUsuario({ ...b, super: false, escritorio_id: usuario.escritorio_id }); } catch (e) { throw new ErroHttp(400, e.message); }
  auditar(usuario, 'usuario.criar', { login: b.login, admin: !!b.admin });
  return { ok: true };
}, { admin: true });
rota('PUT', '/api/usuarios/:id', async ({ req, usuario, m }) => {
  const b = await lerCorpo(req), id = Number(m.id);
  const u = db.prepare('SELECT * FROM usuarios WHERE id = ? AND escritorio_id = ?').get(id, usuario.escritorio_id);
  if (!u) throw new ErroHttp(404, 'Usuário não encontrado.');
  if (u.super && !usuario.super) throw new ErroHttp(403, 'Este usuário só pode ser alterado por ele mesmo.');
  if (id === usuario.id && (b.ativo === false || b.admin === false)) throw new ErroHttp(400, 'Você não pode tirar o próprio acesso de administrador.');
  if ('nome' in b && String(b.nome).trim()) db.prepare('UPDATE usuarios SET nome = ? WHERE id = ?').run(String(b.nome).trim(), id);
  if ('admin' in b) db.prepare('UPDATE usuarios SET admin = ? WHERE id = ?').run(b.admin ? 1 : 0, id);
  if ('ativo' in b) { db.prepare('UPDATE usuarios SET ativo = ? WHERE id = ?').run(b.ativo ? 1 : 0, id); if (!b.ativo) db.prepare('DELETE FROM sessoes WHERE usuario_id = ?').run(id); }
  if (b.senha) {
    if (String(b.senha).length < 6) throw new ErroHttp(400, 'A senha precisa de pelo menos 6 caracteres.');
    db.prepare('UPDATE usuarios SET hash = ? WHERE id = ?').run(auth.hashSenha(b.senha), id);
  }
  auditar(usuario, 'usuario.alterar', { login: u.login, ...b, senha: b.senha ? '(trocada)' : undefined });
  return { ok: true };
}, { admin: true });
rota('POST', '/api/minha-senha', async ({ req, usuario }) => {
  const b = await lerCorpo(req);
  const u = db.prepare('SELECT hash FROM usuarios WHERE id = ?').get(usuario.id);
  if (!auth.confereSenha(String(b.atual || ''), u.hash)) throw new ErroHttp(400, 'Senha atual incorreta.');
  if (String(b.nova || '').length < 6) throw new ErroHttp(400, 'A nova senha precisa de pelo menos 6 caracteres.');
  db.prepare('UPDATE usuarios SET hash = ? WHERE id = ?').run(auth.hashSenha(b.nova), usuario.id);
  return { ok: true };
});
rota('GET', '/api/auditoria', ({ usuario }) => db.prepare('SELECT * FROM auditoria WHERE escritorio_id = ? ORDER BY id DESC LIMIT 300').all(usuario.escritorio_id), { admin: true });

// ---------- ponte com o site (conector): só aceita chamadas vindas do site oficial ----------
const ORIGENS = (process.env.ORIGENS || 'https://gestius-nfse.github.io').split(',').map((o) => o.trim()).filter(Boolean);
async function ponte(req, res, url) {
  const origem = req.headers.origin;
  if (origem && !ORIGENS.includes(origem)) { res.writeHead(403); return res.end(); }
  const cors = origem ? { 'Access-Control-Allow-Origin': origem, 'Vary': 'Origin', 'Access-Control-Allow-Headers': 'authorization, content-type',
    'Access-Control-Allow-Methods': 'GET, POST', 'Access-Control-Allow-Private-Network': 'true', 'Access-Control-Max-Age': '600',
    'Access-Control-Expose-Headers': 'content-disposition' } : {};
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
  for (const [k, v] of Object.entries(cors)) res.setHeader(k, v);
  const sbm = require('./lib/supabase');
  try {
    if (url.pathname === '/ponte/status') {
      const st = sbm.status();
      return jsonR(res, 200, { app: 'gestius-nfse', versao: VERSAO, windows: certs.WINDOWS, conectado: st.configurado, email: st.email,
        escritorio_id: st.configurado ? cfg('sb_escritorio') : null, escritorio: st.escritorio, ult_pub: st.ult_pub, erro: st.erro });
    }
    if (url.pathname === '/ponte/conectar' && req.method === 'POST') {
      // e-mail e senha chegam do site aberto NESTE computador (localhost) e não são guardados: o conector abre a própria sessão
      const b = await lerCorpo(req);
      let st;
      try { st = await sbm.entrar({ email: b.email, senha: b.senha }); } catch (e) { throw new ErroHttp(400, e.message); }
      auditar('site', 'conector.conectado', { email: st.email, escritorio: st.escritorio });
      sbm.publicar().catch(() => {}); sbm.publicarCertificados().catch(() => {});
      return jsonR(res, 200, { ...st, escritorio_id: cfg('sb_escritorio') });
    }
    if (url.pathname === '/ponte/acordar' && req.method === 'POST') {
      sbm.processarComandos().catch(() => {});
      return jsonR(res, 200, { ok: true });
    }
    if (url.pathname === '/ponte/arquivo') {
      const tok = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
      if (!tok) throw new ErroHttp(401, 'Entre no site.');
      if (!sbm.configurado()) throw new ErroHttp(409, 'Este computador ainda não está conectado ao site.');
      const u = await sbm.usuarioDoToken(tok);
      if (!u.papel) throw new ErroHttp(403, 'Você não faz parte do escritório conectado a este computador.');
      const doc = so(url.searchParams.get('doc')), chave = so(url.searchParams.get('chave'));
      const emp = db.prepare('SELECT id FROM empresas WHERE doc = ?').get(doc);
      if (!emp) throw new ErroHttp(404, 'Empresa não encontrada neste computador.');
      if (url.searchParams.get('tipo') === 'pdf') {
        let pdf; try { pdf = await sync.danfse(emp.id, chave); } catch (e) { throw new ErroHttp(502, e.message); }
        return arquivo(res, `${chave}.pdf`, 'application/pdf', pdf);
      }
      const n = db.prepare('SELECT xml FROM notas WHERE empresa_id = ? AND chave = ?').get(emp.id, chave);
      if (!n) throw new ErroHttp(404, 'XML não encontrado neste computador.');
      return arquivo(res, `${chave}.xml`, 'application/xml; charset=utf-8', Buffer.from(n.xml, 'utf8'));
    }
    throw new ErroHttp(404, 'Não encontrado');
  } catch (e) {
    if (!res.headersSent) jsonR(res, e.cod || 400, { erro: e.message || String(e) });
  }
}

// ---------- servidor ----------
const servidor = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname.startsWith('/ponte/') && !NUVEM) return ponte(req, res, url);
  try {
    if (!url.pathname.startsWith('/api/')) {
      if (req.method === 'GET' && estatico(res, url.pathname)) return;
      if (req.method === 'GET') return estatico(res, '/') || jsonR(res, 404, { erro: 'Não encontrado' });
      return jsonR(res, 404, { erro: 'Não encontrado' });
    }
    if (req.method !== 'GET' && req.headers['content-type'] && !/json/.test(req.headers['content-type'])) throw new ErroHttp(415, 'Envie JSON.');
    const usuario = auth.sessao(cookies(req).sid);
    for (const r of rotas) {
      if (r.metodo !== req.method) continue;
      const mm = url.pathname.match(r.re);
      if (!mm) continue;
      let esc = null;
      if (r.token) {
        if (!NUVEM) throw new ErroHttp(404, 'Rota disponível só no site.');
        esc = canal.escritorioPorToken(String(req.headers.authorization || '').replace(/^Bearer\s+/i, ''));
        if (!esc) throw new ErroHttp(401, 'Token do agente inválido.');
      } else {
        if (!r.publico && !usuario) throw new ErroHttp(401, 'Faça login.');
        if (r.admin && !usuario.admin) throw new ErroHttp(403, 'Somente administradores.');
        if (r.superu && !usuario?.super) throw new ErroHttp(403, 'Somente o administrador do site.');
      }
      const m = Object.fromEntries(Object.entries(mm.groups || {}).map(([k, v]) => [k, decodeURIComponent(v)]));
      const out = await r.fn({ req, res, url, usuario, m, esc });
      if (!res.headersSent && out !== undefined) jsonR(res, 200, out);
      return;
    }
    throw new ErroHttp(404, 'Rota não encontrada');
  } catch (e) {
    const cod = e.cod || (e instanceof certs.ErroCert ? 400 : 500);
    if (cod >= 500) console.error(new Date().toISOString(), req.method, url.pathname, e);
    if (!res.headersSent) jsonR(res, cod, { erro: e.message || String(e) });
  }
});

servidor.requestTimeout = 0; servidor.headersTimeout = 65000; servidor.keepAliveTimeout = 65000;
servidor.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`\nA porta ${PORTA} já está em uso: o programa provavelmente já está aberto em outra janela.\nAbra http://localhost:${PORTA} no navegador.\n`);
  else console.error(e);
  process.exit(1);
});
if (MODO === 'agente') { require('./lib/agente').iniciar(); } else servidor.listen(PORTA, REDE, () => {
  console.log(`\nGestius NFS-e ${VERSAO}${NUVEM ? ' (site)' : ''}`);
  console.log(`Abra no navegador: http://localhost:${PORTA}`);
  if (REDE === '0.0.0.0') for (const e of enderecosRede()) console.log(`Na rede:           ${e}`);
  console.log(`Banco de dados:    ${ARQ}`);
  console.log('Deixe esta janela aberta enquanto usar o sistema.\n');
  if (process.env.ABRIR_NAVEGADOR === '1' && process.platform === 'win32') require('child_process').exec(`start "" http://localhost:${PORTA}`);
  sync.iniciarAgendador();
  if (NUVEM && !auth.temUsuarios()) console.log(`CÓDIGO DE INSTALAÇÃO (pedido no primeiro acesso): ${codigoInicial()}\n`);
  // site rodando no computador que tem os certificados: o agente do escritório 1 roda junto, no mesmo programa
  if (NUVEM && process.env.AGENTE_LOCAL === '1') {
    const token = canal.novoToken(1);
    require('./lib/agente').iniciar({ url: `http://127.0.0.1:${PORTA}`, token, gravar_xml: true });
  }
});
