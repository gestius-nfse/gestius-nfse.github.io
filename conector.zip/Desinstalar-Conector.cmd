@echo off
title Desinstalar o conector Gestius NFS-e
set "DESTINO=%LOCALAPPDATA%\Gestius NFS-e Conector"
rem roda a partir de uma copia temporaria para conseguir apagar a propria pasta
if /i not "%~dp0"=="%TEMP%\" ( copy /y "%~f0" "%TEMP%\Desinstalar-Conector.cmd" >nul & start "" "%TEMP%\Desinstalar-Conector.cmd" & exit /b )
echo.
echo Vai desligar e remover o conector Gestius NFS-e deste computador.
echo Os dados no site continuam. Os XML baixados ficam em "%DESTINO%\dados\XML".
echo.
choice /c SN /m "Confirmar (S/N)"
if errorlevel 2 exit /b 0
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 37420 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }" >nul 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Gestius NFS-e Conector.lnk" >nul 2>nul
choice /c SN /m "Apagar tambem os XML e dados guardados neste computador (S/N)"
if errorlevel 2 (
  for %%p in (lib public scripts supabase node_modules) do rmdir /s /q "\\?\%DESTINO%\%%p" 2>nul
  del /q "%DESTINO%\*.*" 2>nul
) else (
  rmdir /s /q "\\?\%DESTINO%"
)
echo.
echo Conector removido.
pause
