' Inicia o conector Gestius NFS-e sem janela
Set fso = CreateObject("Scripting.FileSystemObject")
pasta = fso.GetParentFolderName(WScript.ScriptFullName)
CreateObject("WScript.Shell").Run """" & pasta & "\conector.cmd""", 0, False
