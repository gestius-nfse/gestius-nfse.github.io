'use strict';
// ============================================================
// Gestius NFS-e — interface
// ============================================================
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const so = (s) => String(s ?? '').replace(/\D/g, '');
const brl = (c) => ((Number(c) || 0) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtDoc = (d) => { d = so(d);
  if (d.length === 14) return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  if (d.length === 11) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4'); return d; };
const fmtDH = (s) => { if (!s) return ''; const d = new Date(s); return isNaN(d) ? s : d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); };
const fmtD = (s) => (s ? String(s).slice(0, 10).split('-').reverse().join('/') : '');
const fmtComp = (s) => (s ? s.slice(5, 7) + '/' + s.slice(0, 4) : '');
const iso = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const diasAte = (s) => Math.floor((new Date(s) - new Date()) / 86400000);
const guardado = (k, padrao) => { try { const v = JSON.parse(localStorage.getItem('nfse.' + k)); return v ?? padrao; } catch { return padrao; } };
const guardar = (k, v) => { try { localStorage.setItem('nfse.' + k, JSON.stringify(v)); } catch {} };

// ---------- ícones ----------
const I = {
  empresas: '<path d="M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9Z"/><path d="M4 21c.6-4 3.9-6.5 8-6.5s7.4 2.5 8 6.5"/>',
  notas: '<path d="M14 3H6.5A1.5 1.5 0 0 0 5 4.5v15A1.5 1.5 0 0 0 6.5 21H12"/><path d="M14 3l4 4v4"/><path d="M8 8h5M8 12h5M8 16h3"/><path d="M17 14v7m-2.5-2.5L17 21l2.5-2.5M21 17.5V10m-2.5 2.5L21 10"/>',
  eventos: '<rect x="3.5" y="5" width="17" height="15.5" rx="1.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/><path d="m9 15 2 2 4-4"/>',
  prefs: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>',
  sync: '<path d="M20 11a8 8 0 0 0-14.6-4.5L4 8"/><path d="M4 3.5V8h4.5"/><path d="M4 13a8 8 0 0 0 14.6 4.5L20 16"/><path d="M20 20.5V16h-4.5"/>',
  addUser: '<path d="M10 11.5a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z"/><path d="M3 20.5c.5-3.6 3.4-5.8 7-5.8 1.4 0 2.7.3 3.8.9"/><path d="M18 14v6M15 17h6"/>',
  certs: '<rect x="3" y="4" width="18" height="13" rx="1.5"/><path d="M7 8.5h6M7 12h4"/><circle cx="16.5" cy="12.5" r="2.5"/><path d="m15 15-1 5 2.5-1.3L19 20l-1-5"/>',
  editar: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
  lixo: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  ok: '<circle cx="12" cy="12" r="9" fill="currentColor" stroke="none"/><path d="m8 12.3 2.7 2.7L16 9.7" stroke="#fff" stroke-width="2.2"/>',
  erro: '<circle cx="12" cy="12" r="9" fill="currentColor" stroke="none"/><path d="M9 9l6 6M15 9l-6 6" stroke="#fff" stroke-width="2.2"/>',
  aviso: '<path d="M12 3 2 20h20L12 3Z" fill="currentColor" stroke="none"/><path d="M12 10v4M12 17v.5" stroke="#fff" stroke-width="2.2"/>',
  relogio: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  excel: '<rect x="3" y="3" width="18" height="18" rx="2" fill="#1d7044" stroke="none"/><path d="m8 7.5 8 9M16 7.5l-8 9" stroke="#fff" stroke-width="2.2"/>',
  zip: '<path d="M6 3h8l4 4v14H6z"/><path d="M10 3v2h2v2h-2v2h2v2h-2v2h2"/><rect x="9.5" y="14" width="3" height="4" rx=".5"/>',
  pdf: '<path d="M6 2.5h8.5L19 7v14.5H6z" fill="#fff" stroke="#999"/><rect x="2.5" y="11" width="14" height="6.5" rx="1" fill="#d9342b" stroke="none"/><text x="9.5" y="16.3" font-size="5.2" font-family="Arial" font-weight="700" fill="#fff" stroke="none" text-anchor="middle">PDF</text>',
  xml: '<path d="M6 2.5h8.5L19 7v14.5H6z" fill="#fff" stroke="#7a8db5"/><path d="m10.5 11-2.5 2.5 2.5 2.5M14.5 11l2.5 2.5-2.5 2.5" stroke="#2b5fb3" stroke-width="1.6"/>',
  sair: '<path d="M15 4h3.5A1.5 1.5 0 0 1 20 5.5v13a1.5 1.5 0 0 1-1.5 1.5H15M10 16l-4-4 4-4M6 12h10"/>',
  olho: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="3"/>',
  coracao: '<path d="M12 20s-7.5-4.6-9.2-9.3C1.6 7.3 3.8 4 7.2 4c2 0 3.4 1.1 4.8 2.8C13.4 5.1 14.8 4 16.8 4c3.4 0 5.6 3.3 4.4 6.7C19.5 15.4 12 20 12 20Z"/>',
  filtro: '<path d="M4 5h16l-6.5 7.5V19l-3 1.5v-8z" fill="currentColor"/>',
};
I.apoie = I.coracao;
I.admin = '<path d="M12 3 4.5 6v5.5c0 4.6 3.2 8.4 7.5 9.5 4.3-1.1 7.5-4.9 7.5-9.5V6L12 3Z"/><path d="m9 12 2 2 4-4"/>';
const ico = (n, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${I[n]}</svg>`;

// ---------- API ----------
async function api(metodo, url, corpo) {
  const r = await fetch(url, { method: metodo, headers: corpo ? { 'Content-Type': 'application/json' } : {}, body: corpo ? JSON.stringify(corpo) : undefined, credentials: 'same-origin' });
  let j = null;
  try { j = await r.json(); } catch {}
  if (r.status === 401 && S.usuario) { S.usuario = null; telaLogin(); throw new Error('Sessão expirada. Entre de novo.'); }
  if (!r.ok) throw new Error((j && j.erro) || `Erro ${r.status}`);
  return j;
}
function toast(msg, tipo = '') {
  const t = document.createElement('div');
  t.className = 'toast ' + tipo; t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), tipo === 'erro' ? 7000 : 3500);
}
const tenta = (fn) => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, 'erro'); } };
const lerArquivoB64 = (f) => new Promise((ok, erro) => { const r = new FileReader();
  r.onload = () => ok(String(r.result).split(',')[1]); r.onerror = erro; r.readAsDataURL(f); });

// ---------- estado ----------
const S = {
  usuario: null, windows: false, versao: '',
  aba: guardado('aba', 'empresas'),
  empresas: [], empresaSel: guardado('empresaSel', 'todas'),
  sync: { fila: [], rodando: [] }, buscaEmp: '',
  notas: null, ordN: guardado('ordN', { c: 'dh_proc', d: -1 }), selN: null,
  fN: guardado('fN', { tipo: 'emitida', data: 'geracao', per: 'este_e_passado', ini: '', fim: '', sit: '', ret: '', q: '' }),
  eventos: null, fE: guardado('fE', { per: 'este_e_passado', ini: '', fim: '', codigo: '', q: '' }),
  histQtd: 0,
};

// ---------- períodos ----------
const PERIODOS = { este_mes: 'Este mês', mes_passado: 'Mês passado', este_e_passado: 'Este mês e o passado', ult3: 'Últimos 3 meses', este_ano: 'Este ano', ano_passado: 'Ano passado', livre: 'Personalizado' };
function periodo(p) {
  const h = new Date(), y = h.getFullYear(), m = h.getMonth();
  const r = (a, b) => [iso(a), iso(b)];
  switch (p) {
    case 'este_mes': return r(new Date(y, m, 1), new Date(y, m + 1, 0));
    case 'mes_passado': return r(new Date(y, m - 1, 1), new Date(y, m, 0));
    case 'este_e_passado': return r(new Date(y, m - 1, 1), new Date(y, m + 1, 0));
    case 'ult3': return r(new Date(y, m - 2, 1), new Date(y, m + 1, 0));
    case 'este_ano': return r(new Date(y, 0, 1), new Date(y, 11, 31));
    case 'ano_passado': return r(new Date(y - 1, 0, 1), new Date(y - 1, 11, 31));
  }
  return null;
}
function aplicaPeriodo(f) { const p = periodo(f.per); if (p) [f.ini, f.fim] = p; }
const opcoes = (obj, sel) => Object.entries(obj).map(([v, t]) => `<option value="${esc(v)}" ${String(v) === String(sel) ? 'selected' : ''}>${esc(t)}</option>`).join('');

// ============================================================
// Login
// ============================================================
function telaLogin(modo = 'login') {
  if (modo === true) modo = 'primeiro';
  const prim = modo === 'primeiro', cad = modo === 'cadastro', novo = prim || cad;
  const nuvem = S.modo === 'nuvem';
  $('#app').innerHTML = `<div class="login"><form class="caixa" id="fLogin" autocomplete="on">
    <div class="wm"><b>GESTIUS</b><span>NFS-E</span></div>
    <h1>${cad ? 'Criar conta do escritório' : prim ? 'Primeiro acesso' : 'Entrar'}</h1>
    <p>${cad ? 'Grátis. Baixe as NFS-e de todas as suas empresas do Ambiente Nacional.' : prim ? (nuvem ? 'Crie o administrador do site.' : 'Crie o usuário administrador.') : 'Notas fiscais de serviço de todas as suas empresas, num só lugar.'}</p>
    ${prim && nuvem ? '<label>Código de instalação<input name="codigo" required autocomplete="off" placeholder="aparece no fim da instalação do servidor"></label>' : ''}
    ${novo && (cad || nuvem) ? '<label>Nome do escritório ou da empresa<input name="escritorio" required maxlength="120"></label>' : ''}
    ${novo ? '<label>Seu nome<input name="nome" required autocomplete="name"></label>' : ''}
    ${cad ? '<label>E-mail<input name="email" type="email" required autocomplete="email"></label>' : ''}
    <label>Usuário<input name="login" required autocomplete="username" autocapitalize="none" ${novo ? 'pattern="[A-Za-z0-9._-]{3,40}" title="3 a 40 letras, números, ponto, hífen ou sublinhado"' : ''}></label>
    <label>Senha<input name="senha" type="password" required autocomplete="${novo ? 'new-password' : 'current-password'}" ${novo ? 'minlength="6"' : ''}></label>
    ${novo ? '<label>Repita a senha<input name="senha2" type="password" required minlength="6" autocomplete="new-password"></label>' : ''}
    ${cad ? `<label class="termos"><input type="checkbox" name="aceite" value="1" required style="margin-top:2px">
      <span>Li e aceito: o serviço é gratuito e oferecido "como está"; as notas baixadas ficam guardadas no site para o meu escritório; os certificados ficam no computador do escritório; confiro os valores antes de usá-los em obrigações fiscais.</span></label>` : ''}
    <div class="erro-txt" id="loginErro" style="min-height:18px;margin:-4px 0 8px"></div>
    <button class="btn ${cad ? 'ouro' : 'pri'}">${cad ? 'Criar conta grátis' : prim ? 'Criar e entrar' : 'Entrar'}</button>
    ${S.cadastroAberto && !prim ? `<div class="troca">${cad ? 'Já tem conta? <a data-ir="login">Entrar</a>' : 'Ainda não tem conta? <a data-ir="cadastro">Criar conta grátis</a>'}</div>` : ''}
    <div class="assin">DECISÕES SEGURAS, GESTÃO INTELIGENTE.</div>
  </form></div>`;
  $('#fLogin input').focus();
  $$('[data-ir]').forEach((a) => (a.onclick = () => telaLogin(a.dataset.ir)));
  $('#fLogin').onsubmit = async (ev) => {
    ev.preventDefault();
    const d = Object.fromEntries(new FormData(ev.target));
    if (novo && d.senha !== d.senha2) return ($('#loginErro').textContent = 'As senhas não conferem.');
    if (cad) d.aceite = !!d.aceite;
    try { await api('POST', cad ? '/api/cadastro' : prim ? '/api/primeiro-acesso' : '/api/login', d); iniciar(); }
    catch (e) { $('#loginErro').textContent = e.message; }
  };
}

async function iniciar() {
  const s = await api('GET', '/api/sessao');
  S.versao = s.versao; S.windows = s.windows; S.modo = s.modo; S.nuvem = s.modo === 'nuvem'; S.cadastroAberto = s.cadastroAberto;
  if (!s.usuario) return telaLogin(s.primeiroAcesso ? 'primeiro' : 'login');
  S.usuario = s.usuario;
  montarShell();
  await carregarEmpresas();
  irPara(S.aba);
  vigiarSync();
}

// ============================================================
// Moldura
// ============================================================
const ABAS_BASE = [['empresas', 'Empresas'], ['notas', 'Emitidas / Recebidas'], ['eventos', 'Eventos'], ['apoie', 'Apoie']];
const abas = () => (S.usuario?.super ? [...ABAS_BASE, ['admin', 'Administração']] : ABAS_BASE);
function montarShell() {
  const ini = S.usuario.nome.split(/\s+/).map((p) => p[0]).slice(0, 2).join('').toUpperCase();
  $('#app').innerHTML = `<div class="shell">
    <header class="toolbar">
      <div class="marca" title="Gestius NFS-e ${esc(S.versao)}"><b>GESTIUS</b><span>NFS-E</span></div>
      ${abas().map(([k, t]) => `<button class="tab" data-aba="${k}" title="${t}">${ico(k)}<span>${t}</span></button>`).join('')}
      <div class="sp"></div>
      <div class="tools">
        <button class="ibtn" id="btSync" title="Sincronizar agora (baixa as notas novas)">${ico('sync')}</button>
        <div class="vsep"></div>
        ${S.usuario.admin ? `<button class="ibtn" data-act="novaEmpresa" title="Nova empresa">${ico('addUser')}</button>
        <button class="ibtn" data-act="cadastrarLote" title="Cadastrar várias pelos certificados do Windows">${ico('certs')}</button>` : ''}
        <button class="ibtn" data-act="editarSel" id="btEditar" title="Editar a empresa selecionada">${ico('editar')}</button>
        <select class="selemp" id="selEmp" title="Empresa"></select>
        <button class="ibtn" data-act="prefs" title="Preferências">${ico('prefs')}</button>
        <button class="usuario" data-act="menuUsuario" title="${esc(S.usuario.nome)}"><span class="avatar">${esc(ini)}</span></button>
      </div>
    </header>
    <main class="main" id="main"></main>
    <footer class="status">
      <span id="stEsq"></span>
      ${S.nuvem ? '<button class="agente-st" id="stAg" data-act="agentePrefs" title="Agente do escritório"><i></i><span>Agente…</span></button>' : ''}
      <span class="progresso" id="stProg" hidden><span class="mini"><i></i></span><span id="stProgTxt"></span></span>
      <span class="sp"></span>
      <button class="linkbtn" data-act="historico">${ico('relogio')}<span id="stHist">Histórico</span></button>
    </footer>
  </div>`;
  $$('.tab').forEach((b) => (b.onclick = () => irPara(b.dataset.aba)));
  $('#btSync').onclick = tenta(sincronizar);
  $('#selEmp').onchange = (e) => { S.empresaSel = e.target.value; guardar('empresaSel', S.empresaSel); atualizarEditar(); if (S.aba !== 'empresas') irPara(S.aba); };
}
function preencherSeletor() {
  const sel = $('#selEmp');
  if (!sel) return;
  if (S.empresaSel !== 'todas' && !S.empresas.some((e) => String(e.id) === String(S.empresaSel))) S.empresaSel = 'todas';
  sel.innerHTML = `<option value="todas">Todas as empresas</option>` +
    S.empresas.map((e) => `<option value="${e.id}" ${String(e.id) === String(S.empresaSel) ? 'selected' : ''}>${esc(e.nome)} — ${fmtDoc(e.doc)}</option>`).join('');
  atualizarEditar();
}
function atualizarEditar() { const b = $('#btEditar'); if (b) b.disabled = S.empresaSel === 'todas'; if (b) b.style.opacity = S.empresaSel === 'todas' ? .35 : 1; }

function irPara(aba) {
  S.aba = aba; guardar('aba', aba);
  $$('.tab').forEach((b) => b.classList.toggle('on', b.dataset.aba === aba));
  if (aba === 'admin' && !S.usuario.super) aba = 'empresas';
  ({ empresas: vEmpresas, notas: vNotas, eventos: vEventos, apoie: vApoie, admin: vAdmin }[aba] || vEmpresas)();
}

// delegação de cliques com data-act
const ACOES = {};
document.addEventListener('click', (ev) => {
  const el = ev.target.closest('[data-act]');
  if (!el || el.disabled) return;
  const fn = ACOES[el.dataset.act];
  if (fn) { ev.preventDefault(); tenta(fn)(el, ev); }
});

// ============================================================
// Sincronização (barra de status)
// ============================================================
async function sincronizar(ids) {
  if (!S.empresas.some((e) => e.ativo)) return toast('Cadastre uma empresa primeiro.', 'erro');
  const r = await api('POST', '/api/sync', { ids: Array.isArray(ids) ? ids : S.empresaSel !== 'todas' ? [Number(S.empresaSel)] : [] });
  toast(r.enfileiradas ? `Sincronizando ${r.enfileiradas} empresa(s)…` : 'A sincronização já está em andamento.');
  vigiarSync(true);
}
let timerSync = null, ultimoFimVisto = null;
async function vigiarSync(rapido) {
  clearTimeout(timerSync);
  try {
    const s = await api('GET', '/api/sync/status');
    const antes = S.sync.rodando.length + S.sync.fila.length;
    S.sync = s;
    const ativos = s.rodando.length + s.fila.length;
    const p = $('#stProg');
    if (p) {
      p.hidden = !ativos;
      if (ativos) $('#stProgTxt').textContent = s.rodando.map((r) => `${r.nome}: ${r.novas} nova(s)`).join(' · ') + (s.fila.length ? ` · ${s.fila.length} na fila` : '');
    }
    $('#btSync')?.classList.toggle('girando', !!ativos);
    if (S.nuvem && $('#stAg')) { S.agenteOn = !!s.agente; $('#stAg').className = 'agente-st ' + (s.agente ? 'on' : 'off'); $('#stAg span').textContent = s.agente ? 'Agente conectado' : 'Agente desligado'; }
    if ((antes && !ativos) || (s.ultimoFim && s.ultimoFim !== ultimoFimVisto)) {
      ultimoFimVisto = s.ultimoFim;
      await carregarEmpresas();
      if (S.aba === 'empresas') desenharEmpresas();
      else if (!ativos) irPara(S.aba);
    } else if (ativos && S.aba === 'empresas') desenharEmpresas();
    timerSync = setTimeout(vigiarSync, ativos || rapido ? 1500 : 15000);
  } catch { timerSync = setTimeout(vigiarSync, 15000); }
}

async function carregarEmpresas() {
  S.empresas = await api('GET', '/api/empresas');
  preencherSeletor();
  const ativas = S.empresas.filter((e) => e.ativo).length;
  $('#stEsq').textContent = `${S.empresas.length} empresa(s) cadastrada(s)${ativas !== S.empresas.length ? `, ${ativas} ativa(s)` : ''}.`;
  const erros = S.empresas.filter((e) => e.ult_status === 'erro').length;
  $('#stHist').innerHTML = 'Histórico' + (erros ? ` <span class="pill erro">${erros} com erro</span>` : '');
}

// ============================================================
// Aba Empresas
// ============================================================
function vEmpresas() {
  $('#main').innerHTML = `${S.nuvem && S.agenteOn === false && S.empresas.length ? `<div class="faixa">O agente do escritório está desligado: as notas só baixam quando ele estiver aberto no computador que tem os certificados.
      ${S.usuario.admin ? '<button class="btn" data-act="agentePrefs">Configurar agente</button>' : ''}</div>` : ''}
    <div class="filtros"><input class="busca" style="flex:0 1 420px" id="buscaEmp" placeholder="Procurar empresa" value="${esc(S.buscaEmp)}"></div>
    <div class="grade" id="gEmp"></div>`;
  $('#buscaEmp').oninput = (e) => { S.buscaEmp = e.target.value; desenharEmpresas(); };
  desenharEmpresas();
}
function situacaoCert(e) {
  if (e.cert_origem === 'windows' && !S.windows) return '<span class="pill erro" title="O servidor não está no Windows">sem acesso</span>';
  if (!e.cert_validade) return '<span class="pill cinza">—</span>';
  const d = diasAte(e.cert_validade);
  const tipo = e.cert_origem === 'pfx' ? ' <span class="pill cinza" title="Arquivo .pfx guardado no servidor">.pfx</span>' : '';
  if (d < 0) return `<span class="pill vencido">${fmtD(e.cert_validade)} · vencido</span>${tipo}`;
  if (d <= 30) return `<span class="pill vence">${fmtD(e.cert_validade)} · ${d} dia(s)</span>${tipo}`;
  return fmtD(e.cert_validade) + tipo;
}
function situacaoSync(e) {
  const rod = S.sync.rodando.find((r) => r.id === e.id);
  if (rod) return `<span class="sinc rodando">${ico('sync', 'ico')} sincronizando… ${rod.novas} nova(s)</span>`;
  if (S.sync.fila.includes(e.id)) return `<span class="sinc">${ico('relogio', 'ico')} na fila</span>`;
  if (!e.ult_sync) return '<span class="dica">nunca sincronizada</span>';
  const st = e.ult_status === 'erro' ? 'erro' : e.ult_status === 'aviso' ? 'aviso' : 'ok';
  return `<span class="sinc ${st}" title="${esc(e.ult_msg || '')}">${ico(st, 'ico')} ${fmtDH(e.ult_sync)}${st === 'erro' ? ` <span class="erro-txt">${esc((e.ult_msg || '').slice(0, 70))}</span>` : ''}</span>`;
}
function desenharEmpresas() {
  const g = $('#gEmp');
  if (!g) return;
  const q = S.buscaEmp.trim().toLowerCase(), qd = so(q);
  const lista = S.empresas.filter((e) => !q || e.nome.toLowerCase().includes(q) || (qd && e.doc.includes(qd)));
  if (!S.empresas.length) {
    g.innerHTML = `<div class="vazio"><b>Nenhuma empresa cadastrada.</b><br><br>
      ${S.usuario.admin ? `${S.windows ? `<button class="btn pri" data-act="cadastrarLote">${ico('certs')} Cadastrar pelos certificados do Windows</button>&nbsp; ` : ''}
      <button class="btn" data-act="novaEmpresa">${ico('addUser')} Nova empresa</button>` : 'Peça a um administrador para cadastrar as empresas.'}</div>`;
    return;
  }
  g.innerHTML = `<table><thead><tr><th style="width:44%">Empresa</th><th class="cen">Validade do certificado</th><th class="num">Notas</th><th class="cen">Última sincronização</th><th style="width:96px"></th></tr></thead>
    <tbody>${lista.map((e) => `<tr data-id="${e.id}" class="${e.ativo ? '' : 'inativo'} ${String(e.id) === String(S.empresaSel) ? 'sel' : ''}">
      <td><span style="display:inline-block;min-width:150px">${fmtDoc(e.doc)}</span>${esc(e.nome)}${e.ativo ? '' : ' <span class="pill cinza">inativa</span>'}</td>
      <td class="cen">${situacaoCert(e)}</td>
      <td class="num">${(e.qtd_notas || 0).toLocaleString('pt-BR')}</td>
      <td>${situacaoSync(e)}</td>
      <td><div class="acoes">
        <button data-act="verNotas" data-id="${e.id}" title="Ver notas">${ico('notas')}</button>
        <button data-act="syncUma" data-id="${e.id}" title="Sincronizar só esta empresa">${ico('sync')}</button>
        <button data-act="editarEmpresa" data-id="${e.id}" title="Editar">${ico('editar')}</button>
      </div></td></tr>`).join('')}</tbody></table>
    ${!lista.length ? '<div class="vazio">Nenhuma empresa encontrada.</div>' : ''}`;
  $$('tbody tr', g).forEach((tr) => {
    tr.onclick = () => { S.empresaSel = tr.dataset.id; guardar('empresaSel', S.empresaSel); preencherSeletor(); $$('tbody tr', g).forEach((x) => x.classList.toggle('sel', x === tr)); };
    tr.ondblclick = () => dlgEmpresa(Number(tr.dataset.id));
  });
}
ACOES.agentePrefs = () => ACOES.prefs(null, null, 'agente');
ACOES.verNotas = (el) => { S.empresaSel = el.dataset.id; guardar('empresaSel', S.empresaSel); preencherSeletor(); irPara('notas'); };
ACOES.syncUma = (el) => sincronizar([Number(el.dataset.id)]);
ACOES.editarEmpresa = (el) => dlgEmpresa(Number(el.dataset.id));
ACOES.editarSel = () => S.empresaSel !== 'todas' && dlgEmpresa(Number(S.empresaSel));
ACOES.novaEmpresa = () => dlgEmpresa(null);

// ---------- diálogo genérico ----------
function dialogo({ titulo, corpo, rodape = '', tamanho = '', abas = '' }) {
  const ov = document.createElement('div');
  ov.className = 'ov';
  ov.innerHTML = `<div class="dlg ${tamanho}" role="dialog" aria-label="${esc(titulo)}">
    <div class="dlg-hd"><svg class="logo" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="#1e8e3e"/><path d="M10 8h8l5 5v11H10z" fill="none" stroke="#fff" stroke-width="2.4"/></svg><b>${esc(titulo)}</b><button class="x" data-fechar title="Fechar">×</button></div>
    ${abas}<div class="dlg-bd">${corpo}</div>${rodape ? `<div class="dlg-ft">${rodape}</div>` : ''}</div>`;
  document.body.appendChild(ov);
  const fechar = () => { ov.remove(); document.removeEventListener('keydown', tecla); };
  const tecla = (e) => { if (e.key === 'Escape' && document.body.lastElementChild === ov) fechar(); };
  document.addEventListener('keydown', tecla);
  $$('[data-fechar]', ov).forEach((b) => (b.onclick = fechar));
  return { el: ov, fechar };
}

// ---------- cadastro / edição de empresa ----------
async function dlgEmpresa(id) {
  if (!S.usuario.admin && !id) return;
  const e = id ? S.empresas.find((x) => x.id === id) : null;
  if (id && !e) return;
  let certsWin = [];
  if (S.windows) try { const r = await api('GET', '/api/certificados'); certsWin = r.lista; if (r.erro) toast(r.erro, 'erro'); } catch (er) { toast(er.message, 'erro'); }
  const ro = !S.usuario.admin;
  const st = { origem: e ? e.cert_origem : S.windows ? 'windows' : 'pfx', pfxB64: null, pfxInfo: null };
  const idx = id ? S.empresas.findIndex((x) => x.id === id) : -1;

  const d = dialogo({
    titulo: e ? 'Editar empresa' : 'Nova empresa', tamanho: 'lg',
    abas: `<div class="dlg-tabs"><button class="on">Empresa</button><span class="sp"></span>
      ${e ? `<span class="dica" style="align-self:center">
        <button class="btn" style="height:26px;padding:0 8px" data-nav="-1" ${idx <= 0 ? 'disabled' : ''}>‹</button> ${idx + 1} de ${S.empresas.length}
        <button class="btn" style="height:26px;padding:0 8px" data-nav="1" ${idx >= S.empresas.length - 1 ? 'disabled' : ''}>›</button></span>`
        : S.windows ? `<button class="lnk" data-lote>${ico('addUser', 'ico')} Cadastrar várias pelos certificados do Windows…</button>` : ''}</div>`,
    corpo: `<form id="fEmp" autocomplete="off">
      <div class="secao">Identificação</div>
      <div class="form">
        <label>Situação</label><div><select name="ativo" style="width:140px"><option value="1">Ativo</option><option value="0" ${e && !e.ativo ? 'selected' : ''}>Inativo</option></select></div>
        <label>CNPJ ou CPF</label><div class="linha"><input name="doc" style="width:210px" value="${e ? fmtDoc(e.doc) : ''}" ${e ? '' : 'autofocus'} inputmode="numeric"><span class="dica" id="docDica"></span></div>
        <label>Razão social</label><input name="nome" style="max-width:540px" value="${esc(e?.nome || '')}">
      </div>
      <div class="secao">Certificado digital</div>
      <div class="aviso" style="margin-bottom:12px"><b>Certificado da empresa:</b> serve para baixar as notas emitidas e recebidas.<br>
        <b>Certificado de outra empresa do mesmo grupo:</b> o ADN aceita certificado com a mesma raiz de CNPJ (8 primeiros dígitos), por exemplo da matriz para a filial.</div>
      <div class="form">
        <label>Origem</label>
        <div class="linha">
          <label class="chk"><input type="radio" name="origem" value="windows" ${st.origem === 'windows' ? 'checked' : ''} ${S.windows ? '' : 'disabled'}> Instalado no Windows</label>
          ${S.nuvem ? '<span class="dica" style="margin-left:14px">(o agente encontra o certificado no Windows do escritório; .pfx: instale no Windows com dois cliques)</span>' : `<label class="chk" style="margin-left:14px"><input type="radio" name="origem" value="pfx" ${st.origem === 'pfx' ? 'checked' : ''}> Arquivo .pfx guardado no sistema</label>`}
        </div>
        <label class="soWin">Certificado</label>
        <div class="linha soWin"><select name="cert_thumb" style="flex:1;max-width:620px"></select>
          <button type="button" class="btn" data-recarregar>Recarregar</button></div>
        <label class="soWin"></label>
        <label class="chk soWin"><input type="checkbox" name="cert_auto" ${!e || e.cert_auto ? 'checked' : ''}> Localizar o certificado pelo CNPJ/CPF a cada download (a renovação entra sozinha)</label>
        <label class="soPfx">Arquivo .pfx</label>
        <div class="linha soPfx"><input type="file" name="pfx" accept=".pfx,.p12" style="flex:1;max-width:380px">
          <input type="password" name="senha" placeholder="Senha do certificado" style="width:200px" autocomplete="new-password">
          <button type="button" class="btn" data-lerpfx>Ler</button></div>
        <label class="soPfx"></label><div class="dica soPfx" id="pfxDica">${e && e.tem_pfx ? 'Há um .pfx guardado (cifrado). Escolha outro arquivo só para trocar.' : 'O arquivo e a senha ficam guardados cifrados no servidor.'}</div>
        <label>Emissor</label><input id="cEmissor" disabled style="max-width:380px">
        <label>Validade</label><div class="linha"><input id="cValidade" disabled style="width:200px"><button type="button" class="btn" data-testar>Testar acesso</button><span id="testeRes" class="dica"></span></div>
      </div>
      <div class="secao">Download</div>
      <div class="form">
        <label>Pasta dos XML</label>
        <div class="linha"><select name="pasta_modo" style="width:200px"><option value="padrao">Padrão (Preferências)</option><option value="outra" ${e?.pasta_xml ? 'selected' : ''}>Outro lugar</option></select>
          <input name="pasta_xml" style="flex:1;max-width:520px" value="${esc(e?.pasta_xml || '')}" placeholder="Pasta das preferências + nome da empresa"></div>
        <label>Último NSU</label>
        <div class="linha"><input name="ult_nsu" type="number" min="0" style="width:140px" value="${e ? e.ult_nsu : 0}">
          <button type="button" class="btn" data-zerar>Zerar</button>
          <span class="dica">Zerar baixa tudo de novo desde o início (as notas que já estão no banco não duplicam).</span></div>
      </div>
    </form>`,
    rodape: `${e && S.usuario.admin ? '<button class="btn perigo esq" data-excluir>Excluir empresa</button>' : ''}
      <button class="btn" data-fechar>Cancelar</button>${ro ? '' : '<button class="btn pri" data-salvar>Salvar</button>'}`,
  });
  const f = $('#fEmp', d.el);
  if (ro) $$('input,select,button:not([data-fechar])', d.el).forEach((x) => { if (!x.matches('[data-testar],[data-nav]')) x.disabled = true; });

  const preencherCerts = () => {
    const doc = so(f.doc.value);
    const raiz = doc.length === 14 ? doc.slice(0, 8) : null;
    const ordem = (c) => (c.doc === doc ? 0 : raiz && c.doc && c.doc.slice(0, 8) === raiz ? 1 : 2);
    const lista = [...certsWin].sort((a, b) => ordem(a) - ordem(b) || a.titular.localeCompare(b.titular));
    const atual = e?.cert_thumb;
    f.cert_thumb.innerHTML = '<option value="">— nenhum certificado —</option>' + lista.map((c) => `<option value="${c.thumb}" ${c.thumb === atual ? 'selected' : ''}>${esc(c.titular)}  ${fmtDoc(c.doc)}  · vence ${fmtD(c.validade)}${c.vencido ? '  [VENCIDO]' : ''}</option>`).join('');
    if (!f.cert_thumb.value) { const m = lista.find((c) => c.doc === doc && !c.vencido) || lista.find((c) => ordem(c) === 1 && !c.vencido); if (m) f.cert_thumb.value = m.thumb; }
    mostrarCert();
  };
  const mostrarCert = () => {
    let em = '', va = '';
    if (st.origem === 'windows') { const c = certsWin.find((x) => x.thumb === f.cert_thumb.value); if (c) { em = c.emissor; va = c.validade; } }
    else if (st.pfxInfo) { em = st.pfxInfo.emissor; va = st.pfxInfo.validade; }
    else if (e && e.cert_origem === 'pfx') { em = e.cert_emissor || ''; va = e.cert_validade || ''; }
    $('#cEmissor', d.el).value = em || '';
    $('#cValidade', d.el).value = va ? `${fmtD(va)}  (${diasAte(va)} dias)` : '';
  };
  const origem = () => {
    st.origem = f.origem.value;
    $$('.soWin', d.el).forEach((x) => (x.hidden = st.origem !== 'windows'));
    $$('.soPfx', d.el).forEach((x) => (x.hidden = st.origem !== 'pfx'));
    mostrarCert();
  };
  const pasta = () => { const o = f.pasta_modo.value === 'outra'; f.pasta_xml.disabled = !o || ro; if (!o) f.pasta_xml.value = ''; };
  $$('[name=origem]', d.el).forEach((r) => (r.onchange = origem));
  f.cert_thumb.onchange = mostrarCert;
  f.pasta_modo.onchange = pasta;
  f.doc.oninput = () => {
    const doc = so(f.doc.value);
    const c = certsWin.find((x) => x.doc === doc && !x.vencido);
    if (c && !f.nome.value) f.nome.value = c.titular;
    const ja = !e && S.empresas.find((x) => x.doc === doc);
    $('#docDica', d.el).innerHTML = ja ? '<span class="erro-txt">já cadastrada</span>' : c ? '<span class="ok-txt">certificado encontrado no Windows</span>' : '';
    preencherCerts();
  };
  f.doc.onblur = () => { if (so(f.doc.value).length >= 11) f.doc.value = fmtDoc(f.doc.value); };
  $('[data-zerar]', d.el).onclick = () => (f.ult_nsu.value = 0);
  $('[data-recarregar]', d.el).onclick = tenta(async () => { certsWin = (await api('GET', '/api/certificados?recarregar=1')).lista; preencherCerts(); toast('Lista de certificados atualizada.'); });
  const lerPfx = async () => {
    const arq = f.pfx.files[0];
    if (!arq) throw new Error('Escolha o arquivo .pfx.');
    st.pfxB64 = await lerArquivoB64(arq);
    st.pfxInfo = await api('POST', '/api/pfx/ler', { pfxBase64: st.pfxB64, senha: f.senha.value });
    $('#pfxDica', d.el).innerHTML = `<span class="ok-txt">${esc(st.pfxInfo.titular)} · ${fmtDoc(st.pfxInfo.doc)}</span>`;
    if (!so(f.doc.value) && st.pfxInfo.doc) { f.doc.value = fmtDoc(st.pfxInfo.doc); }
    if (!f.nome.value) f.nome.value = st.pfxInfo.titular;
    mostrarCert();
  };
  $('[data-lerpfx]', d.el).onclick = tenta(lerPfx);
  f.pfx.onchange = () => { st.pfxB64 = null; st.pfxInfo = null; if (f.senha.value) tenta(lerPfx)(); };
  $('[data-testar]', d.el).onclick = tenta(async () => {
    const res = $('#testeRes', d.el);
    res.className = 'dica'; res.textContent = 'Testando…';
    if (st.origem === 'pfx' && f.pfx.files[0] && !st.pfxB64) await lerPfx();
    const r = await api('POST', '/api/testar', { id, doc: so(f.doc.value), cert_origem: st.origem, cert_auto: f.cert_auto.checked, cert_thumb: f.cert_thumb.value,
      pfxBase64: st.pfxB64, senha: f.senha.value });
    res.className = r.ok ? 'ok-txt' : 'erro-txt';
    res.textContent = r.ok ? `Acesso ao ADN funcionando (${r.host}).` : r.erro;
  });
  $('[data-lote]', d.el)?.addEventListener('click', () => { d.fechar(); dlgLote(); });
  $$('[data-nav]', d.el).forEach((b) => (b.onclick = () => { d.fechar(); dlgEmpresa(S.empresas[idx + Number(b.dataset.nav)].id); }));
  $('[data-excluir]', d.el)?.addEventListener('click', () => confirmar(`Excluir ${e.nome}?`, 'As notas e eventos desta empresa saem do banco. Os arquivos XML já gravados na pasta continuam lá.', 'Excluir', tenta(async () => {
    await api('DELETE', '/api/empresas/' + id); d.fechar(); toast('Empresa excluída.'); await carregarEmpresas(); irPara(S.aba);
  })));
  $('[data-salvar]', d.el)?.addEventListener('click', tenta(async () => {
    if (st.origem === 'pfx' && f.pfx.files[0] && !st.pfxB64) await lerPfx();
    if (st.origem === 'pfx' && !st.pfxB64 && !(e && e.tem_pfx)) throw new Error('Escolha o arquivo .pfx e informe a senha.');
    if (st.origem === 'windows' && !f.cert_thumb.value && !f.cert_auto.checked) throw new Error('Escolha o certificado.');
    const c = certsWin.find((x) => x.thumb === f.cert_thumb.value);
    const corpo = { doc: so(f.doc.value), nome: f.nome.value, ativo: f.ativo.value === '1', cert_origem: st.origem, cert_auto: f.cert_auto.checked,
      cert_thumb: st.origem === 'windows' ? f.cert_thumb.value : e?.cert_thumb, cert_titular: c?.titular ?? e?.cert_titular, cert_doc: c?.doc ?? e?.cert_doc,
      cert_emissor: c?.emissor ?? e?.cert_emissor, cert_validade: c?.validade ?? e?.cert_validade,
      pasta_xml: f.pasta_modo.value === 'outra' ? f.pasta_xml.value : '', ult_nsu: f.ult_nsu.value,
      pfxBase64: st.origem === 'pfx' ? st.pfxB64 : null, senha: f.senha.value };
    if (id) await api('PUT', '/api/empresas/' + id, corpo);
    else { const r = await api('POST', '/api/empresas', corpo); S.empresaSel = String(r.id); guardar('empresaSel', S.empresaSel); }
    d.fechar();
    toast(id ? 'Empresa salva.' : 'Empresa cadastrada. Baixando as notas…', 'ok');
    await carregarEmpresas(); irPara(S.aba); vigiarSync(true);
  }));
  preencherCerts(); origem(); pasta();
  f.doc.focus();
}

function confirmar(titulo, texto, botao, fn) {
  const d = dialogo({ titulo, tamanho: 'sm', corpo: `<p style="margin:0">${esc(texto)}</p>`,
    rodape: `<button class="btn" data-fechar>Cancelar</button><button class="btn pri" data-sim>${esc(botao)}</button>` });
  $('[data-sim]', d.el).onclick = async () => { d.fechar(); await fn(); };
}

// ---------- cadastro em lote pelos certificados do Windows ----------
ACOES.cadastrarLote = () => dlgLote();
async function dlgLote() {
  if (!S.windows) {
    dialogo({ titulo: 'Certificados do Windows', tamanho: 'sm', rodape: '<button class="btn pri" data-fechar>OK</button>',
      corpo: '<p style="margin:0">O servidor não está rodando no Windows, então não tem acesso à loja de certificados. Cadastre as empresas com o arquivo .pfx.</p>' });
    return;
  }
  const r0 = await api('GET', '/api/certificados');
  if (r0.erro) throw new Error(r0.erro);
  let lista = r0.lista;
  const d = dialogo({
    titulo: 'Cadastrar várias pelos certificados do Windows', tamanho: 'lg',
    corpo: `<div class="linha" style="margin-bottom:10px"><input id="lBusca" placeholder="Procurar certificado" style="flex:1">
      <button class="btn" data-todas>Selecionar todas as válidas</button><button class="btn" data-nenhuma>Limpar seleção</button><button class="btn" data-rec>Recarregar</button></div>
      <div class="lista-certs" id="lLista"></div>
      <div class="linha" style="margin-top:10px"><label class="chk"><input type="checkbox" id="lSync" checked> Baixar as notas logo após cadastrar</label>
      <span class="sp grow"></span><span class="dica" id="lCont"></span></div>
      <p class="dica" style="margin:8px 0 0">Aparecem os certificados ICP-Brasil com chave privada da loja "Pessoal" do Windows ${S.nuvem ? 'do computador onde o agente está aberto' : 'deste servidor'}. Certificados A3 (token/cartão) pedem PIN e não baixam sozinhos.</p>`,
    rodape: '<button class="btn" data-fechar>Cancelar</button><button class="btn pri" data-cad>Cadastrar</button>',
  });
  const marcados = new Set();
  const desenhar = () => {
    const q = $('#lBusca', d.el).value.trim().toLowerCase(), qd = so(q);
    const vis = lista.filter((c) => !q || c.titular.toLowerCase().includes(q) || (qd && (c.doc || '').includes(qd)));
    $('#lLista', d.el).innerHTML = `<table><thead><tr><th style="width:32px"></th><th>Titular</th><th>CNPJ/CPF</th><th>Validade</th><th>Emissor</th><th></th></tr></thead><tbody>
      ${vis.map((c) => { const off = c.cadastrada || c.vencido || !c.doc;
        return `<tr class="${off ? 'off' : ''}"><td><input type="checkbox" data-t="${c.thumb}" ${marcados.has(c.thumb) ? 'checked' : ''} ${off ? 'disabled' : ''}></td>
        <td>${esc(c.titular)}</td><td>${fmtDoc(c.doc)}</td><td>${fmtD(c.validade)}</td><td>${esc(c.emissor)}</td>
        <td>${c.cadastrada ? '<span class="pill info">já cadastrada</span>' : c.vencido ? '<span class="pill vencido">vencido</span>' : !c.doc ? '<span class="pill cinza">sem CNPJ/CPF</span>' : ''}</td></tr>`; }).join('')}
      </tbody></table>${vis.length ? '' : '<div class="vazio">Nenhum certificado encontrado.</div>'}`;
    $$('[data-t]', d.el).forEach((x) => (x.onchange = () => { x.checked ? marcados.add(x.dataset.t) : marcados.delete(x.dataset.t); contar(); }));
    contar();
  };
  // o mesmo CNPJ pode ter o certificado antigo e o renovado: marca só o de maior validade
  const validas = () => { const vistos = new Set(); return lista.filter((c) => !c.cadastrada && !c.vencido && c.doc).sort((a, b) => b.validade.localeCompare(a.validade))
    .filter((c) => (vistos.has(c.doc) ? false : vistos.add(c.doc))); };
  const contar = () => { $('#lCont', d.el).textContent = `${marcados.size} selecionado(s) · ${lista.filter((c) => c.cadastrada).length} já cadastrada(s)`; $('[data-cad]', d.el).textContent = marcados.size ? `Cadastrar ${marcados.size}` : 'Cadastrar'; };
  $('#lBusca', d.el).oninput = desenhar;
  $('[data-todas]', d.el).onclick = () => { validas().forEach((c) => marcados.add(c.thumb)); desenhar(); };
  $('[data-nenhuma]', d.el).onclick = () => { marcados.clear(); desenhar(); };
  $('[data-rec]', d.el).onclick = tenta(async () => { lista = (await api('GET', '/api/certificados?recarregar=1')).lista; desenhar(); });
  $('[data-cad]', d.el).onclick = tenta(async () => {
    if (!marcados.size) throw new Error('Selecione pelo menos um certificado.');
    // evita cadastrar duas vezes o mesmo CNPJ (certificado antigo + renovado)
    const porDoc = new Map();
    for (const c of lista.filter((x) => marcados.has(x.thumb))) if (!porDoc.has(c.doc) || porDoc.get(c.doc).validade < c.validade) porDoc.set(c.doc, c);
    const r = await api('POST', '/api/empresas/lote', { thumbs: [...porDoc.values()].map((c) => c.thumb), sincronizar: $('#lSync', d.el).checked });
    d.fechar();
    toast(`${r.criadas} empresa(s) cadastrada(s)${r.ignoradas.length ? `, ${r.ignoradas.length} ignorada(s)` : ''}.`, 'ok');
    await carregarEmpresas(); irPara('empresas'); vigiarSync(true);
  });
  desenhar();
}

// ============================================================
// Aba Emitidas / Recebidas
// ============================================================
function vNotas() {
  const f = S.fN;
  if (f.per !== 'livre') aplicaPeriodo(f);
  $('#main').innerHTML = `
    <div class="filtros">
      <select id="nTipo">${opcoes({ emitida: 'Emitidas', recebida: 'Recebidas', todas: 'Emitidas e recebidas' }, f.tipo)}</select>
      <select id="nData">${opcoes({ geracao: 'Data de geração', competencia: 'Competência' }, f.data)}</select>
      <select id="nPer">${opcoes(PERIODOS, f.per)}</select>
      <input type="date" class="data" id="nIni" value="${f.ini}"><input type="date" class="data" id="nFim" value="${f.fim}">
    </div>
    <div class="filtros">
      <select id="nSit">${opcoes({ '': 'Todas as situações', regular: 'Regular', cancelada: 'Cancelada', substituida: 'Substituída' }, f.sit)}</select>
      <select id="nRet">${opcoes({ '': 'Com e sem ret., desc. e ded.', com: 'Com retenção, desconto ou dedução', sem: 'Sem retenção, desconto ou dedução' }, f.ret)}</select>
      <select id="nReg">${opcoes({ '': 'Todos os regimes', 1: 'Não optante', 2: 'Optante - MEI', 3: 'Optante - ME/EPP' }, f.regime || '')}</select>
      <input class="busca" id="nQ" placeholder="Procurar por número, nome, CNPJ, chave de acesso ou descrição do serviço" value="${esc(f.q)}">
      <button class="btn pri" id="nFiltrar">${ico('filtro')} Filtrar</button><button class="btn" id="nLimpar">Limpar</button>
    </div>
    <div class="grade" id="gN"><div class="vazio">Carregando…</div></div>
    <div class="rodape">
      <button class="btn" data-act="planilhaN">${ico('excel')} Planilha</button>
      <button class="btn" data-act="zipN">${ico('zip')} Zip</button>
      <span class="cont" id="nCont"></span>
    </div>
    <div class="totais" id="nTot"></div>`;
  const ler = () => { Object.assign(f, { tipo: $('#nTipo').value, data: $('#nData').value, per: $('#nPer').value, ini: $('#nIni').value, fim: $('#nFim').value,
    sit: $('#nSit').value, ret: $('#nRet').value, regime: $('#nReg').value, q: $('#nQ').value }); guardar('fN', f); };
  $('#nPer').onchange = () => { ler(); if (f.per !== 'livre') { aplicaPeriodo(f); $('#nIni').value = f.ini; $('#nFim').value = f.fim; } carregarNotas(); };
  ['nIni', 'nFim'].forEach((i) => ($('#' + i).onchange = () => { $('#nPer').value = 'livre'; ler(); carregarNotas(); }));
  ['nTipo', 'nData', 'nSit', 'nRet', 'nReg'].forEach((i) => ($('#' + i).onchange = () => { ler(); carregarNotas(); }));
  $('#nQ').onkeydown = (e) => { if (e.key === 'Enter') { ler(); carregarNotas(); } };
  $('#nFiltrar').onclick = () => { ler(); carregarNotas(); };
  $('#nLimpar').onclick = () => { Object.assign(f, { sit: '', ret: '', regime: '', q: '', per: 'este_e_passado' }); guardar('fN', f); vNotas(); };
  carregarNotas();
}
const qsNotas = () => { const f = S.fN; return new URLSearchParams({ empresa: S.empresaSel, tipo: f.tipo, data: f.data, ini: f.ini, fim: f.fim, sit: f.sit, ret: f.ret, regime: f.regime || '', q: f.q }).toString(); };
const carregarNotas = tenta(async () => {
  const g = $('#gN');
  if (!g) return;
  S.notas = await api('GET', '/api/notas?' + qsNotas());
  desenharNotas();
});
const COLN = [
  ['dh_proc', 'Geração', (n) => fmtDH(n.dh_proc)], ['d_compet', 'Competência', (n) => fmtComp(n.d_compet)],
  ['prest_nome', 'Emitida por', (n) => `<span class="tag">P</span>${fmtDoc(n.prest_doc)} - ${esc(n.prest_nome)}`, 'recebida'],
  ['toma_nome', 'Emitida para', (n) => `<span class="tag t">T</span>${fmtDoc(n.toma_doc)} - ${esc(n.toma_nome)}`, 'emitida'],
  ['numero', 'NFS-e', (n) => esc(n.numero)], ['v_serv', 'Preço Serviço (R$)', (n) => brl(n.v_serv), null, 'num'],
  ['v_iss', 'ISS (R$)', (n) => brl(n.v_iss) + (n.iss_retido ? ' <span class="pill aviso" title="ISS retido">ret</span>' : ''), null, 'num'],
  ['situacao', 'Situação', (n) => `<span class="pill ${n.situacao}">${{ regular: 'Regular', cancelada: 'Cancelada', substituida: 'Substituída' }[n.situacao] || n.situacao}</span>`, null, 'cen'],
];
function desenharNotas() {
  const g = $('#gN'), N = S.notas;
  if (!g || !N) return;
  const tipo = S.fN.tipo;
  const cols = COLN.filter((c) => !c[3] || tipo === 'todas' || c[3] === tipo);
  const { c: oc, d: od } = S.ordN;
  const linhas = [...N.linhas].sort((a, b) => { const x = a[oc] ?? '', y = b[oc] ?? ''; return (typeof x === 'number' ? x - y : String(x).localeCompare(String(y), 'pt-BR', { numeric: true })) * od; });
  if (!linhas.length) {
    const semEmp = !S.empresas.length;
    g.innerHTML = `<div class="vazio">${semEmp ? '<b>Cadastre uma empresa</b> para começar.' : `Nenhuma nota ${tipo === 'emitida' ? 'emitida' : tipo === 'recebida' ? 'recebida' : ''} no período.<br><span class="dica">Se acabou de cadastrar a empresa, aguarde a sincronização terminar (barra de baixo).</span>`}</div>`;
  } else {
    g.innerHTML = `<table><thead><tr>${cols.map(([k, t, , , cl]) => `<th data-ord="${k}" class="${cl || ''}">${t}${oc === k ? `<span class="ord">${od > 0 ? '▲' : '▼'}</span>` : ''}</th>`).join('')}<th class="cen" style="width:76px">PDF/XML</th></tr></thead>
      <tbody>${linhas.map((n, i) => `<tr data-i="${N.linhas.indexOf(n)}">${cols.map(([, , fn, , cl]) => `<td class="${cl || ''}">${fn(n)}</td>`).join('')}
      <td><div class="docbtns"><a href="/api/notas/${n.empresa_id}/${n.chave}/pdf" target="_blank" title="DANFSe (PDF)">${ico('pdf')}</a><a href="/api/notas/${n.empresa_id}/${n.chave}/xml" title="Baixar XML">${ico('xml')}</a></div></td></tr>`).join('')}</tbody></table>`;
    $$('th[data-ord]', g).forEach((th) => (th.onclick = () => { const k = th.dataset.ord; S.ordN = { c: k, d: S.ordN.c === k ? -S.ordN.d : 1 }; guardar('ordN', S.ordN); desenharNotas(); }));
    $$('tbody tr', g).forEach((tr) => {
      tr.onclick = (ev) => { if (ev.target.closest('a')) return; $$('tbody tr', g).forEach((x) => x.classList.toggle('sel', x === tr)); };
      tr.ondblclick = (ev) => { if (!ev.target.closest('a')) detalheNota(N.linhas[tr.dataset.i]); };
    });
  }
  const t = N.totais;
  $('#nCont').textContent = `${t.total.toLocaleString('pt-BR')} registro(s) · ${t.empresas} empresa(s)${t.total > N.linhas.length ? ` · mostrando ${N.linhas.length}` : ''}`;
  const bloco = (titulo, pares, total) => `<fieldset><legend>${titulo}</legend><dl>${pares.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}
    ${total !== undefined ? `<dt class="tot">Total</dt><dd class="tot">${total}</dd>` : ''}</dl></fieldset>`;
  const vRet = t.v_iss_retido + t.v_ret_cp + t.v_ret_irrf + t.v_ret_csll;
  $('#nTot').innerHTML =
    bloco('Documentos', [['Regular', t.regular], ['Cancelada', t.cancelada], ['Substituída', t.substituida]], t.total) +
    bloco('Totais (só Regular)', [['vServ', brl(t.v_serv)], ['vDescIncond', brl(t.v_desc_incond)], ['vDescCond', brl(t.v_desc_cond)], ['vDR', brl(t.v_dr)], ['vTotalRet', brl(t.v_total_ret)], ['vLiq', brl(t.v_liq)]]) +
    bloco('Retenções (só Regular)', [['vISSQN retido', brl(t.v_iss_retido)], ['vRetCP', brl(t.v_ret_cp)], ['vRetIRRF', brl(t.v_ret_irrf)], ['vRetCSLL', brl(t.v_ret_csll)]], brl(vRet)) +
    bloco('Impostos (só Regular)', [['vISSQN', brl(t.v_iss)], ['vPis', brl(t.v_pis)], ['vCofins', brl(t.v_cofins)]], brl(t.v_iss + t.v_pis + t.v_cofins)) +
    bloco('IBS/CBS (só Regular)', [['vIBSUF', brl(t.v_ibs_uf)], ['vIBSMun', brl(t.v_ibs_mun)], ['vCBS', brl(t.v_cbs)], ['vIBSSN', brl(t.v_ibs_sn)], ['vCBSSN', brl(t.v_cbs_sn)]], brl(t.v_ibs_uf + t.v_ibs_mun + t.v_cbs + t.v_ibs_sn + t.v_cbs_sn));
}
function baixar(url) { const a = document.createElement('a'); a.href = url; a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove(); }
ACOES.planilhaN = () => {
  if (!S.notas?.totais.total) throw new Error('Nenhuma nota no filtro.');
  const tipo = S.fN.tipo, emp = S.empresaSel === 'todas' ? 'Todas as empresas' : (S.empresas.find((e) => String(e.id) === String(S.empresaSel)) || {}).nome;
  const marc = guardado('abasPlan', ['emitidas', 'recebidas']);
  const op = [['emitidas', 'Emitidas', tipo !== 'recebida'], ['recebidas', 'Recebidas', tipo !== 'emitida'], ['mes', 'Total por mês (emitidas − recebidas)', true], ['ctn', 'Total por código de serviço (cTribNac/NBS)', true]];
  const d = dialogo({ titulo: 'Planilha', tamanho: 'sm',
    corpo: `<b>${esc(emp)}</b><div class="dica">${fmtD(S.fN.ini)} a ${fmtD(S.fN.fim)} (por ${S.fN.data === 'competencia' ? 'competência' : 'data de geração'})</div>
      <div style="margin:12px 0 6px">Abas da planilha:</div>
      ${op.map(([k, t, ok]) => `<label class="chk" style="display:flex;margin:6px 0"><input type="checkbox" data-aba="${k}" ${ok && marc.includes(k) ? 'checked' : ''} ${ok ? '' : 'disabled'}> ${t}</label>`).join('')}
      <p class="dica">Totais somam só as notas regulares e respeitam o filtro do Excel.</p>`,
    rodape: '<button class="btn" data-fechar>Cancelar</button><button class="btn pri" data-ok>Salvar</button>' });
  $('[data-ok]', d.el).onclick = () => {
    const abas = $$('[data-aba]', d.el).filter((x) => x.checked).map((x) => x.dataset.aba);
    if (!abas.length) return toast('Escolha pelo menos uma aba.', 'erro');
    guardar('abasPlan', abas); d.fechar();
    baixar('/api/notas/planilha?' + qsNotas() + '&abas=' + abas.join(','));
  };
};
ACOES.zipN = () => { if (!S.notas?.totais.total) throw new Error('Nenhuma nota no filtro.'); baixar('/api/notas/zip?' + qsNotas()); };

async function detalheNota(l) {
  const n = await api('GET', `/api/notas/${l.empresa_id}/${l.chave}`);
  const ov = document.createElement('div'); ov.className = 'lado-ov';
  const p = document.createElement('aside'); p.className = 'lado';
  const kv = (pares) => '<dl class="kv">' + pares.filter((x) => x[1] !== '' && x[1] !== null && x[1] !== undefined).map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('') + '</dl>';
  p.innerHTML = `<div class="dlg-hd"><b>NFS-e ${esc(n.numero)} · ${n.tipo === 'emitida' ? 'emitida' : 'recebida'}</b><button class="x" title="Fechar">×</button></div>
    <div class="dlg-bd">
      <div class="linha" style="margin-bottom:12px"><a class="btn" href="/api/notas/${n.empresa_id}/${n.chave}/pdf" target="_blank">${ico('pdf')} DANFSe</a><a class="btn" href="/api/notas/${n.empresa_id}/${n.chave}/xml">${ico('xml')} XML</a>
      <span class="pill ${n.situacao}">${n.situacao}</span></div>
      <h3>Identificação</h3>${kv([['Empresa', esc(n.emp_nome)], ['Chave de acesso', `<span class="mono">${esc(n.chave)}</span>`], ['Geração', fmtDH(n.dh_proc)], ['Emissão da DPS', fmtDH(n.dh_emi)], ['Competência', fmtD(n.d_compet)], ['Município', esc(n.municipio)], ['NSU', n.nsu]])}
      <h3>Partes</h3>${kv([['Prestador', `${fmtDoc(n.prest_doc)} - ${esc(n.prest_nome)}`], ['Tomador', `${fmtDoc(n.toma_doc)} - ${esc(n.toma_nome)}`]])}
      <h3>Serviço</h3>${kv([['Cód. trib. nacional', esc(n.cod_trib)], ['Descrição', esc(n.descricao)]])}
      <h3>Valores</h3>${kv([['Valor do serviço', 'R$ ' + brl(n.v_serv)], ['Desc. incondicionado', n.v_desc_incond ? 'R$ ' + brl(n.v_desc_incond) : ''], ['Desc. condicionado', n.v_desc_cond ? 'R$ ' + brl(n.v_desc_cond) : ''], ['Deduções/reduções', n.v_dr ? 'R$ ' + brl(n.v_dr) : ''],
        ['Base de cálculo', 'R$ ' + brl(n.v_bc)], ['Alíquota ISS', n.p_aliq ? n.p_aliq.replace('.', ',') + ' %' : ''], ['ISS', 'R$ ' + brl(n.v_iss) + (n.iss_retido ? ' (retido)' : '')],
        ['Ret. CP / IRRF / CSLL', n.v_ret_cp + n.v_ret_irrf + n.v_ret_csll ? `${brl(n.v_ret_cp)} / ${brl(n.v_ret_irrf)} / ${brl(n.v_ret_csll)}` : ''],
        ['PIS / COFINS', n.v_pis + n.v_cofins ? `${brl(n.v_pis)} / ${brl(n.v_cofins)}` : ''], ['IBS UF / Mun / CBS', n.v_ibs_uf + n.v_ibs_mun + n.v_cbs ? `${brl(n.v_ibs_uf)} / ${brl(n.v_ibs_mun)} / ${brl(n.v_cbs)}` : ''],
        ['Total retido', 'R$ ' + brl(n.v_total_ret)], ['Valor líquido', '<b>R$ ' + brl(n.v_liq) + '</b>']])}
      <h3>Eventos</h3>${n.eventos.length ? `<table class="hist">${n.eventos.map((e) => `<tr><td>${fmtDH(e.dh_evento)}</td><td>${esc(e.descricao)}<div class="dica">${esc(e.motivo || '')}</div></td><td><a href="/api/eventos/${n.empresa_id}/${e.nsu}/xml" title="XML do evento">${ico('xml', 'ico')}</a></td></tr>`).join('')}</table>` : '<span class="dica">Nenhum evento.</span>'}
      ${n.arquivo ? `<h3>Arquivo</h3><div class="mono dica">${esc(n.arquivo)}</div>` : ''}
    </div>`;
  document.body.append(ov, p);
  const fechar = () => { ov.remove(); p.remove(); document.removeEventListener('keydown', tecla); };
  const tecla = (e) => e.key === 'Escape' && fechar();
  ov.onclick = fechar; $('.x', p).onclick = fechar; document.addEventListener('keydown', tecla);
}

// ============================================================
// Aba Eventos
// ============================================================
const TIPOS_EV = { '': 'Todos os eventos', e101101: 'Cancelamento', e105102: 'Cancelamento por substituição', e101103: 'Solicitação de análise fiscal p/ cancelamento',
  e202201: 'Confirmação do prestador', e203202: 'Confirmação do tomador', e205204: 'Confirmação tácita', e202205: 'Rejeição do prestador', e203206: 'Rejeição do tomador',
  e205208: 'Anulação da rejeição', e305101: 'Cancelamento por ofício', e305102: 'Bloqueio por ofício', e305103: 'Desbloqueio por ofício' };
function vEventos() {
  const f = S.fE;
  if (f.per !== 'livre') aplicaPeriodo(f);
  $('#main').innerHTML = `
    <div class="filtros">
      <select id="ePer">${opcoes(PERIODOS, f.per)}</select>
      <input type="date" class="data" id="eIni" value="${f.ini}"><input type="date" class="data" id="eFim" value="${f.fim}">
      <select id="eCod" style="min-width:260px">${opcoes(TIPOS_EV, f.codigo)}</select>
    </div>
    <div class="filtros"><input class="busca" style="flex:0 1 480px" id="eQ" placeholder="Procurar por evento, chave, autor ou motivo" value="${esc(f.q)}">
      <button class="btn pri" id="eFiltrar">${ico('filtro')} Filtrar</button><button class="btn" id="eLimpar">Limpar</button></div>
    <div class="grade" id="gE"><div class="vazio">Carregando…</div></div>
    <div class="rodape"><button class="btn" data-act="planilhaE">${ico('excel')} Gerar relação</button><span class="cont" id="eCont"></span></div>`;
  const ler = () => { Object.assign(f, { per: $('#ePer').value, ini: $('#eIni').value, fim: $('#eFim').value, codigo: $('#eCod').value, q: $('#eQ').value }); guardar('fE', f); };
  $('#ePer').onchange = () => { ler(); if (f.per !== 'livre') { aplicaPeriodo(f); $('#eIni').value = f.ini; $('#eFim').value = f.fim; } carregarEventos(); };
  ['eIni', 'eFim'].forEach((i) => ($('#' + i).onchange = () => { $('#ePer').value = 'livre'; ler(); carregarEventos(); }));
  $('#eCod').onchange = () => { ler(); carregarEventos(); };
  $('#eQ').onkeydown = (e) => { if (e.key === 'Enter') { ler(); carregarEventos(); } };
  $('#eFiltrar').onclick = () => { ler(); carregarEventos(); };
  $('#eLimpar').onclick = () => { Object.assign(f, { codigo: '', q: '', per: 'este_e_passado' }); guardar('fE', f); vEventos(); };
  carregarEventos();
}
const qsEventos = () => new URLSearchParams({ empresa: S.empresaSel, ini: S.fE.ini, fim: S.fE.fim, codigo: S.fE.codigo, q: S.fE.q }).toString();
const carregarEventos = tenta(async () => {
  const g = $('#gE'); if (!g) return;
  const lista = S.eventos = await api('GET', '/api/eventos?' + qsEventos());
  $('#eCont').textContent = `${lista.length} evento(s)`;
  g.innerHTML = lista.length ? `<table><thead><tr><th>Evento</th><th>Geração</th><th>NFS-e</th><th>Empresa</th><th>Autor</th><th>Motivo</th><th class="cen">XML</th></tr></thead><tbody>
    ${lista.map((e) => `<tr><td>${esc(e.descricao)}</td><td>${fmtDH(e.dh_evento)}</td><td>${esc(e.numero || e.chave_nfse.slice(-15))}</td><td>${esc(e.emp_nome)}</td><td>${fmtDoc(e.autor)}</td><td title="${esc(e.motivo)}">${esc(e.motivo)}</td>
    <td class="cen"><a href="/api/eventos/${e.empresa_id}/${e.nsu}/xml" title="Baixar XML">${ico('xml', 'ico')}</a></td></tr>`).join('')}</tbody></table>`
    : '<div class="vazio">Nenhum evento no período.</div>';
});
ACOES.planilhaE = () => { if (!S.eventos?.length) throw new Error('Nenhum evento no filtro.'); baixar('/api/eventos/planilha?' + qsEventos()); };

// ============================================================
// Apoie (doação por Pix)
// ============================================================
let valorPix = guardado('valorPix', 0);
async function vApoie() {
  $('#main').innerHTML = '<div class="apoie" id="pix"><div class="vazio">Carregando…</div></div>';
  const desenhar = async () => {
    const p = await api('GET', '/api/pix?valor=' + valorPix / 100);
    const vals = [0, 1000, 2000, 5000, 10000];
    $('#pix').innerHTML = `<div class="apoie-card">
      <div class="apoie-txt">
        <h2>${ico('coracao', 'ico-g')} Apoie o Gestius NFS-e</h2>
        <p>${esc(p.texto)}</p>
        <div class="dica" style="margin:14px 0 6px">Escolha um valor (ou deixe em aberto e digite no app do banco):</div>
        <div class="linha">${vals.map((v) => `<button class="btn ${v === valorPix ? 'pri' : ''}" data-v="${v}">${v ? 'R$ ' + brl(v) : 'Valor livre'}</button>`).join('')}
          <input id="pixOutro" placeholder="Outro valor" inputmode="decimal" style="width:120px" value="${vals.includes(valorPix) ? '' : brl(valorPix)}"></div>
        <div class="dica" style="margin:16px 0 6px">Pix copia e cola:</div>
        <div class="linha"><input id="pixCod" readonly value="${esc(p.payload)}" style="flex:1" class="mono"><button class="btn pri" id="pixCopiar">Copiar código</button></div>
        <dl class="kv" style="margin-top:16px"><dt>Chave Pix (e-mail)</dt><dd><b>${esc(p.chave)}</b> <button class="btn" style="height:24px;padding:0 8px" id="pixChave">copiar</button></dd><dt>Recebedor</dt><dd>${esc(p.nome)}</dd></dl>
        <p class="dica" style="margin-top:14px">Confira o nome do recebedor no app do banco antes de confirmar. Obrigado!</p>
      </div>
      <div class="apoie-qr"><div class="qr">${p.svg}</div><div class="dica">Abra o app do banco → Pix → Ler QR Code${p.centavos ? `<br><b>R$ ${brl(p.centavos)}</b>` : ''}</div></div>
    </div>`;
    $$('[data-v]').forEach((b) => (b.onclick = () => { valorPix = Number(b.dataset.v); guardar('valorPix', valorPix); tenta(desenhar)(); }));
    $('#pixOutro').onchange = (e) => { const c = Math.round(Number(e.target.value.replace(/\./g, '').replace(',', '.')) * 100) || 0; valorPix = c; guardar('valorPix', c); tenta(desenhar)(); };
    const copiar = async (txt, b) => { try { await navigator.clipboard.writeText(txt); b.textContent = 'Copiado!'; } catch { $('#pixCod').select(); document.execCommand('copy'); b.textContent = 'Copiado!'; } setTimeout(() => (b.textContent = b.id === 'pixChave' ? 'copiar' : 'Copiar código'), 1800); };
    $('#pixCopiar').onclick = () => copiar(p.payload, $('#pixCopiar'));
    $('#pixChave').onclick = () => copiar(p.chave, $('#pixChave'));
  };
  tenta(desenhar)();
}

// ============================================================
// Histórico
// ============================================================
ACOES.historico = async () => {
  const h = await api('GET', '/api/historico' + (S.empresaSel !== 'todas' ? '?empresa=' + S.empresaSel : ''));
  const st = { ok: 'ok', aviso: 'aviso', erro: 'erro', rodando: 'info' };
  dialogo({ titulo: 'Histórico de sincronização', tamanho: 'lg', rodape: '<button class="btn pri" data-fechar>Fechar</button>',
    corpo: h.length ? `<table class="hist"><thead><tr><th style="text-align:left">Início</th><th style="text-align:left">Empresa</th><th>Situação</th><th class="num">Novas</th><th class="num">NSU</th><th style="text-align:left">Mensagem</th></tr></thead><tbody>
      ${h.map((x) => `<tr><td>${fmtDH(x.inicio)}<div class="dica">${x.origem || ''}</div></td><td>${esc(x.nome || '(excluída)')}</td><td class="cen"><span class="pill ${st[x.status] || 'cinza'}">${x.status}</span></td>
      <td class="num">${x.novas}${x.eventos ? ` + ${x.eventos} ev.` : ''}</td><td class="num">${x.nsu_de ?? ''} → ${x.nsu_ate ?? ''}</td><td style="white-space:normal">${esc(x.msg || '')}</td></tr>`).join('')}</tbody></table>`
      : '<div class="vazio">Nenhuma sincronização ainda.</div>' });
};

// ============================================================
// Usuário e preferências
// ============================================================
ACOES.menuUsuario = (el) => {
  $('.menu')?.remove();
  const r = el.getBoundingClientRect();
  const m = document.createElement('div'); m.className = 'menu';
  m.style.top = r.bottom + 4 + 'px'; m.style.right = innerWidth - r.right + 'px';
  m.innerHTML = `<div style="padding:6px 14px 8px"><b>${esc(S.usuario.nome)}</b><div class="dica">${esc(S.usuario.login)}${S.usuario.admin ? ' · administrador' : ''}</div></div><hr>
    <button data-m="senha">Trocar minha senha</button><button data-m="sair">Sair</button>`;
  document.body.appendChild(m);
  setTimeout(() => document.addEventListener('click', function f(e) { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('click', f); } }), 0);
  $('[data-m=sair]', m).onclick = tenta(async () => { await api('POST', '/api/logout'); location.reload(); });
  $('[data-m=senha]', m).onclick = () => { m.remove(); dlgMinhaSenha(); };
};
function dlgMinhaSenha() {
  const d = dialogo({ titulo: 'Trocar minha senha', tamanho: 'sm',
    corpo: `<div class="form" style="grid-template-columns:120px 1fr"><label>Senha atual</label><input type="password" id="sA"><label>Nova senha</label><input type="password" id="sN" minlength="6"><label>Repita</label><input type="password" id="sR"></div>`,
    rodape: '<button class="btn" data-fechar>Cancelar</button><button class="btn pri" data-ok>Salvar</button>' });
  $('[data-ok]', d.el).onclick = tenta(async () => {
    if ($('#sN', d.el).value !== $('#sR', d.el).value) throw new Error('As senhas não conferem.');
    await api('POST', '/api/minha-senha', { atual: $('#sA', d.el).value, nova: $('#sN', d.el).value }); d.fechar(); toast('Senha trocada.', 'ok');
  });
}

ACOES.prefs = async (el, ev, inicial) => {
  if (!S.usuario.admin) return dlgMinhaSenha();
  const c = await api('GET', '/api/config');
  const secoes = !S.nuvem ? [['site', 'Site na internet'], ['xml', 'Arquivos XML'], ['download', 'Download'], ['banco', 'Banco de dados'], ['rede', 'Rede e usuários'], ['pix', 'Doações (Pix)'], ['auditoria', 'Auditoria']]
    : S.usuario.super ? [['agente', 'Agente do escritório'], ['usuarios', 'Usuários'], ['download', 'Site e download'], ['pix', 'Doações (Pix)'], ['banco', 'Banco de dados'], ['auditoria', 'Auditoria']]
    : [['agente', 'Agente do escritório'], ['usuarios', 'Usuários'], ['auditoria', 'Auditoria']];
  const salva = !S.nuvem || S.usuario.super;
  const d = dialogo({ titulo: 'Preferências', tamanho: 'lg',
    corpo: `<div class="prefs"><nav>${secoes.map(([k, t], i) => `<button data-sec="${k}" class="${i ? '' : 'on'}">${t}</button>`).join('')}</nav><div class="conteudo" id="pCont"></div></div>`,
    rodape: salva ? '<button class="btn" data-fechar>Cancelar</button><button class="btn pri" data-salvar>Salvar</button>' : '<button class="btn pri" data-fechar>Fechar</button>' });
  $('.dlg-bd', d.el).style.padding = '0';
  const v = { ...c };
  const ex = () => {
    const base = (v.pasta_xml || '').replace(/[\\/]+$/, ''), sep = base.includes('\\') ? '\\' : '/';
    const sub = { emitida: v.pasta_emitidas, recebida: v.pasta_recebidas, evento: v.pasta_eventos };
    const p = (t, nome, mes) => [base, 'EMPRESA LTDA', ...({ 'empresa/ano/mes/tipo': ['2026', mes, sub[t]], 'empresa/tipo/ano/mes': [sub[t], '2026', mes], 'empresa/tipo': [sub[t]], 'empresa/ano/mes': ['2026', mes] }[v.subpastas] || []), nome].join(sep);
    return [p('emitida', '42054001…000001230.xml', '08'), p('recebida', '42054001…000000770.xml', '08'), p('evento', '42054001…_e101101_1001.xml', '09')].join('<br>');
  };
  const telas = {
    xml: () => `<div class="secao">Arquivos XML</div><div class="form" style="grid-template-columns:120px 1fr">
      <label>Pasta geral</label><input data-k="pasta_xml" value="${esc(v.pasta_xml)}">
      <label></label><div class="dica">Pasta no computador onde o servidor está rodando. Cada empresa ganha uma pasta dentro desta, com o nome do cadastro. Para guardar no servidor da rede, use um caminho de rede (\\\\servidor\\pasta).</div></div>
      <div class="secao">Organização</div><div class="form" style="grid-template-columns:120px 1fr">
      <label>Subpastas</label><select data-k="subpastas">${opcoes({ 'empresa/ano/mes/tipo': 'Empresa / AAAA / MM / Tipo', 'empresa/tipo/ano/mes': 'Empresa / Tipo / AAAA / MM', 'empresa/ano/mes': 'Empresa / AAAA / MM', 'empresa/tipo': 'Empresa / Tipo' }, v.subpastas)}</select>
      <label>Emitidas</label><input data-k="pasta_emitidas" value="${esc(v.pasta_emitidas)}" style="max-width:220px">
      <label>Recebidas</label><input data-k="pasta_recebidas" value="${esc(v.pasta_recebidas)}" style="max-width:220px">
      <label>Eventos</label><input data-k="pasta_eventos" value="${esc(v.pasta_eventos)}" style="max-width:220px">
      <label>Ano/mês pela</label><div class="linha"><label class="chk"><input type="radio" name="am" data-k="anomes_pela" value="competencia" ${v.anomes_pela !== 'geracao' ? 'checked' : ''}> Data de competência</label>
        <label class="chk" style="margin-left:12px"><input type="radio" name="am" data-k="anomes_pela" value="geracao" ${v.anomes_pela === 'geracao' ? 'checked' : ''}> Data de geração</label><span class="dica">Eventos: pela data do evento</span></div>
      <label>Exemplo</label><div class="mono dica" id="pEx">${ex()}</div></div>
      <div class="secao">PDF (DANFSe)</div>
      <label class="chk"><input type="checkbox" data-k="gravar_pdf" ${v.gravar_pdf === '1' ? 'checked' : ''}> Gravar também o PDF ao lado do XML quando o DANFSe for aberto</label>
      <p class="dica">O PDF oficial vem do ADN na primeira vez que alguém abre a nota e fica guardado no banco. O botão "Zip" inclui os PDFs já guardados.</p>`,
    download: () => `${S.nuvem ? `<div class="secao">Cadastro</div><label class="chk"><input type="checkbox" data-k="cadastro_aberto" ${v.cadastro_aberto !== '0' ? 'checked' : ''}> Qualquer pessoa pode criar conta de escritório na tela de entrada</label>` : ''}<div class="secao">Baixar sozinho</div><div class="form" style="grid-template-columns:120px 1fr">
      <label>Frequência</label><select data-k="frequencia" style="max-width:300px">${opcoes({ 0: 'Só quando eu clicar em Sincronizar', 30: 'A cada 30 minutos', 60: 'A cada 1 hora', 120: 'A cada 2 horas', 240: 'A cada 4 horas', diario: 'Uma vez por dia' }, v.frequencia)}</select>
      <label>Horário</label><input type="time" data-k="horario" value="${esc(v.horario)}" style="width:120px" ${v.frequencia === 'diario' ? '' : 'disabled'}>
      <label></label><div class="dica">Se outro sistema também consulta o ADN com o mesmo certificado (como o programa desktop), escolha um horário diferente do dele: os dois juntos podem passar do limite de acessos.<br><br>
      Com o servidor desligado no horário, ele baixa assim que for ligado. O botão Sincronizar baixa na hora, a qualquer momento.<br><br>
      Certificados A3 (token ou cartão) pedem PIN e não baixam sozinhos.</div></div>
      <div class="secao">Ambiente</div><div class="form" style="grid-template-columns:120px 1fr">
      <label>ADN</label><select data-k="ambiente" style="max-width:300px">${opcoes({ producao: 'Produção (notas reais)', homologacao: 'Produção restrita (testes)' }, v.ambiente)}</select>
      <label>Pausa</label><div class="linha"><input type="number" data-k="pausa_ms" value="${esc(v.pausa_ms)}" min="0" max="5000" style="width:100px"> <span class="dica">milissegundos entre uma chamada e outra ao ADN</span></div></div>`,
    banco: () => `<div class="secao">Banco de dados</div><div class="form" style="grid-template-columns:120px 1fr">
      <label>Arquivo</label><input value="${esc(c.banco)}" disabled>
      <label></label><div class="dica">Fica sempre no computador do servidor. Em pasta de rede o banco pode se corromper numa queda de conexão; para ter uma cópia na rede, use a cópia de segurança.</div></div>
      <div class="secao">Cópia de segurança</div><div class="form" style="grid-template-columns:120px 1fr">
      <label>Pasta</label><input data-k="backup_dir" value="${esc(v.backup_dir)}">
      <label></label><div class="dica">Uma cópia por dia; ficam as 7 mais recentes. Para proteger contra perda do disco, escolha uma pasta no OneDrive, na rede ou num pendrive.<br>Última cópia: ${c.ult_backup ? fmtD(c.ult_backup) : 'nenhuma'}.</div>
      <label></label><div><button class="btn" data-bk>Fazer cópia agora</button></div></div>`,
    rede: () => `<div class="secao">Acesso pela rede</div>
      <label class="chk"><input type="checkbox" data-k="compartilhar_rede" ${v.compartilhar_rede === '1' ? 'checked' : ''}> Permitir que outros computadores da rede abram o sistema</label>
      <p class="dica">${c.rede_ativa ? 'Ativo. Endereços para os outros computadores:<br>' + c.enderecos.map((e) => `<b class="mono">${esc(e)}</b>`).join('<br>') : 'Desligado: só este computador acessa (http://localhost). Depois de ligar, feche e abra o servidor de novo.'}<br>
      Todos entram com usuário e senha. O Windows pode pedir para liberar o Node no firewall.</p>
      <div class="secao">Usuários</div><div id="pUsu">Carregando…</div>`,
    pix: () => `<div class="secao">Doações (aba Apoie)</div><div class="form" style="grid-template-columns:120px 1fr">
      <label>Chave Pix</label><input data-k="pix_chave" value="${esc(v.pix_chave)}" style="max-width:360px">
      <label>Recebedor</label><input data-k="pix_nome" value="${esc(v.pix_nome)}" maxlength="25" style="max-width:360px">
      <label>Cidade</label><input data-k="pix_cidade" value="${esc(v.pix_cidade)}" maxlength="15" style="max-width:220px">
      <label>Texto</label><textarea data-k="pix_texto" rows="3">${esc(v.pix_texto)}</textarea>
      <label></label><div class="dica">Nome (até 25 letras) e cidade (até 15) vão dentro do QR Code, sem acentos. O banco de quem paga mostra o nome do titular da chave.</div></div>`,
    usuarios: () => '<div class="secao">Usuários do escritório</div><div id="pUsu">Carregando…</div>',
    agente: () => '<div class="secao">Agente do escritório</div><div id="pAg">Carregando…</div>',
    site: () => '<div class="secao">Site na internet (Supabase)</div><div id="pSite">Carregando…</div>',
    auditoria: () => '<div class="secao">Últimas alterações</div><div id="pAud">Carregando…</div>',
  };
  const coletar = () => $$('[data-k]', d.el).forEach((x) => { if (x.type === 'radio') { if (x.checked) v[x.dataset.k] = x.value; } else v[x.dataset.k] = x.type === 'checkbox' ? (x.checked ? '1' : '0') : x.value; });
  const mostrar = (k) => {
    coletar();
    $$('[data-sec]', d.el).forEach((b) => b.classList.toggle('on', b.dataset.sec === k));
    $('#pCont', d.el).innerHTML = telas[k]();
    $$('[data-k]', d.el).forEach((x) => (x.oninput = x.onchange = () => { coletar(); if ($('#pEx', d.el)) $('#pEx', d.el).innerHTML = ex(); const h = $('[data-k=horario]', d.el); if (h) h.disabled = v.frequencia !== 'diario'; }));
    $('[data-bk]', d.el)?.addEventListener('click', tenta(async () => { const r = await api('POST', '/api/backup'); toast('Cópia gravada em ' + r.arquivo, 'ok'); }));
    if (k === 'rede' || k === 'usuarios') usuarios($('#pUsu', d.el));
    if (k === 'agente') painelAgente($('#pAg', d.el));
    if (k === 'site') painelSite($('#pSite', d.el));
    if (k === 'auditoria') auditoria($('#pAud', d.el));
  };
  $$('[data-sec]', d.el).forEach((b) => (b.onclick = () => mostrar(b.dataset.sec)));
  $('[data-salvar]', d.el)?.addEventListener('click', tenta(async () => {
    coletar();
    const r = await api('PUT', '/api/config', v);
    d.fechar();
    toast(r.reiniciar ? 'Preferências salvas. Feche e abra o servidor para mudar o acesso pela rede.' : 'Preferências salvas.', 'ok');
  }));
  mostrar(inicial && secoes.some(([k]) => k === inicial) ? inicial : secoes[0][0]);
};
async function usuarios(el) {
  const lista = await api('GET', '/api/usuarios');
  el.innerHTML = `<table class="hist"><thead><tr><th style="text-align:left">Nome</th><th style="text-align:left">Usuário</th><th>Perfil</th><th>Situação</th><th></th></tr></thead><tbody>
    ${lista.map((u) => `<tr><td>${esc(u.nome)}</td><td>${esc(u.login)}</td><td class="cen">${u.admin ? 'Administrador' : 'Operador'}</td><td class="cen"><span class="pill ${u.ativo ? 'ok' : 'cinza'}">${u.ativo ? 'ativo' : 'inativo'}</span></td>
    <td class="num"><button class="btn" style="height:26px" data-u="${u.id}">Editar</button></td></tr>`).join('')}</tbody></table>
    <div style="margin-top:10px"><button class="btn" data-novo>+ Novo usuário</button></div>
    <p class="dica">Administrador cadastra empresas, certificados e preferências. Operador consulta, baixa planilhas e sincroniza.</p>`;
  const editar = (u) => {
    const d = dialogo({ titulo: u ? 'Editar usuário' : 'Novo usuário', tamanho: 'sm',
      corpo: `<div class="form" style="grid-template-columns:110px 1fr"><label>Nome</label><input id="uN" value="${esc(u?.nome || '')}">
        <label>Usuário</label><input id="uL" value="${esc(u?.login || '')}" ${u ? 'disabled' : ''} autocapitalize="none">
        <label>${u ? 'Nova senha' : 'Senha'}</label><input id="uS" type="password" placeholder="${u ? 'deixe em branco para manter' : 'mínimo 6 caracteres'}" autocomplete="new-password">
        <label>Perfil</label><select id="uA"><option value="0">Operador</option><option value="1" ${u?.admin ? 'selected' : ''}>Administrador</option></select>
        ${u ? `<label>Situação</label><select id="uAt"><option value="1">Ativo</option><option value="0" ${u.ativo ? '' : 'selected'}>Inativo</option></select>` : ''}</div>`,
      rodape: '<button class="btn" data-fechar>Cancelar</button><button class="btn pri" data-ok>Salvar</button>' });
    $('[data-ok]', d.el).onclick = tenta(async () => {
      const corpo = { nome: $('#uN', d.el).value, admin: $('#uA', d.el).value === '1' };
      if ($('#uS', d.el).value) corpo.senha = $('#uS', d.el).value;
      if (u) { corpo.ativo = $('#uAt', d.el).value === '1'; await api('PUT', '/api/usuarios/' + u.id, corpo); }
      else await api('POST', '/api/usuarios', { ...corpo, login: $('#uL', d.el).value, senha: $('#uS', d.el).value });
      d.fechar(); toast('Usuário salvo.', 'ok'); usuarios(el);
    });
  };
  $$('[data-u]', el).forEach((b) => (b.onclick = () => editar(lista.find((u) => u.id === Number(b.dataset.u)))));
  $('[data-novo]', el).onclick = () => editar(null);
}
async function painelSite(el) {
  const st = await api('GET', '/api/supabase');
  const ok = st.configurado;
  el.innerHTML = `<p class="dica" style="margin:0 0 12px">Este computador continua sendo o principal: certificados, downloads, XML e PDF ficam aqui.
    Para o site, ele envia <b>só os dados de visualização</b> das notas (número, datas, partes, valores, situação e eventos), depois de cada sincronização e a cada 10 minutos.</p>
    ${ok ? `<p><span class="agente-st on"><i></i><b>Conectado</b></span> como <b>${esc(st.email)}</b> · escritório <b>${esc(st.escritorio)}</b></p>
      <dl class="kv"><dt>Última publicação</dt><dd>${st.ult_pub ? fmtDH(st.ult_pub) : 'ainda não'}</dd><dt>Aguardando envio</dt><dd>${st.pendentes.toLocaleString('pt-BR')} registro(s)</dd>
      ${st.site ? `<dt>Endereço do site</dt><dd><a href="${esc(st.site)}" target="_blank" rel="noopener">${esc(st.site)}</a></dd>` : ''}
      ${st.erro ? `<dt>Último erro</dt><dd class="erro-txt">${esc(st.erro)}</dd>` : ''}</dl>
      <div class="linha" style="margin-top:12px"><button class="btn pri" data-pub>Publicar agora</button><button class="btn" data-sairsb>Desconectar</button></div>`
    : `<div class="form" style="grid-template-columns:150px 1fr">
      ${st.padrao ? '' : `<label>Endereço do Supabase</label><input id="sbUrl" value="${esc(st.url)}" placeholder="https://xxxx.supabase.co">
      <label>Chave pública (anon)</label><input id="sbAnon" value="${esc(st.anon)}" placeholder="eyJhbGciOi...">`}
      <label>E-mail no site</label><input id="sbEmail" type="email" value="${esc(st.email)}" placeholder="o e-mail do administrador do escritório no site">
      <label>Senha do site</label><input id="sbSenha" type="password" autocomplete="off">
      <label></label><div><button class="btn pri" data-entrar>Conectar e publicar</button></div>
      <label></label><div class="dica">Ainda não tem conta? Crie no site, em "Criar conta grátis". A senha não fica guardada neste computador, só um acesso que se renova sozinho.</div></div>
      ${st.erro ? `<p class="erro-txt">${esc(st.erro)}</p>` : ''}`}`;
  $('[data-entrar]', el)?.addEventListener('click', tenta(async () => {
    await api('POST', '/api/supabase/entrar', { url: $('#sbUrl', el)?.value, anon: $('#sbAnon', el)?.value, email: $('#sbEmail', el).value, senha: $('#sbSenha', el).value });
    toast('Conectado. Publicando as notas no site…', 'ok'); painelSite(el);
  }));
  $('[data-pub]', el)?.addEventListener('click', tenta(async (ev) => {
    ev.target.disabled = true; ev.target.textContent = 'Publicando…';
    try { const r = await api('POST', '/api/supabase/publicar'); toast(`Publicado: ${r.resultado?.notas || 0} nota(s) e ${r.resultado?.eventos || 0} evento(s).`, 'ok'); } finally { painelSite(el); }
  }));
  $('[data-sairsb]', el)?.addEventListener('click', tenta(async () => { await api('POST', '/api/supabase/sair'); painelSite(el); }));
}

async function painelAgente(el) {
  const a = await api('GET', '/api/agente/info');
  el.innerHTML = `<p style="margin:0 0 10px"><span class="agente-st ${a.online ? 'on' : 'off'}"><i></i><b>${a.online ? 'Conectado' : 'Desligado'}</b></span>
    ${a.agente_visto ? `<span class="dica">· visto em ${fmtDH(a.agente_visto)}${a.agente_host ? ' no computador ' + esc(a.agente_host) : ''}${a.agente_versao ? ' · versão ' + esc(a.agente_versao) : ''}</span>` : '<span class="dica">· ainda não foi instalado</span>'}</p>
    <p style="margin:0 0 10px">Endereço do site: <b class="mono">${esc(a.endereco)}</b></p>
    ${a.embutido ? '<p class="faixa" style="margin:0 0 12px">Este escritório usa o agente embutido: ele roda junto com o site neste computador. Os passos abaixo são para outros computadores.</p>' : ''}
    <p class="dica" style="margin:0 0 12px">O agente é um programa pequeno que fica aberto no computador do escritório que tem os certificados digitais instalados no Windows.
      Ele baixa as notas no Ambiente Nacional e envia para este site. <b>Os certificados nunca saem desse computador</b>, e ele não precisa de porta aberta no roteador.</p>
    <ol class="passos">
      <li>Nesse computador, instale o Node.js (uma vez): <span class="mono">winget install OpenJS.NodeJS.LTS</span></li>
      <li><a class="btn" href="/api/agente/download" style="height:26px">Baixar o agente</a> e extraia num lugar fixo.</li>
      <li>Gere o token abaixo, abra o <b>iniciar-agente.bat</b> e cole o token quando ele pedir.</li>
      <li>Deixe a janela aberta (pode minimizar). O selo no rodapé do site fica verde.</li>
    </ol>
    <div class="secao">Token</div>
    <p class="dica" style="margin:0 0 8px">${a.token_prefixo ? `Token atual começa com <b class="mono">${esc(a.token_prefixo)}…</b>. Gerar outro desliga o agente que usa o atual.` : 'Nenhum token gerado ainda.'}</p>
    <div id="tokNovo"></div>
    <button class="btn ${a.token_prefixo ? '' : 'pri'}" data-tok>${a.token_prefixo ? 'Gerar novo token' : 'Gerar token'}</button>`;
  $('[data-tok]', el).onclick = tenta(async () => {
    const r = await api('POST', '/api/agente/token');
    $('#tokNovo', el).innerHTML = `<div class="token">${esc(r.token)}</div><div class="linha" style="margin:8px 0 12px"><button class="btn pri" data-cp>Copiar token</button><span class="dica">Ele só aparece agora. Guarde até colar no agente.</span></div>`;
    $('[data-cp]', el).onclick = async (e) => { try { await navigator.clipboard.writeText(r.token); e.target.textContent = 'Copiado!'; } catch { toast('Selecione e copie o token.', 'erro'); } };
  });
}

// ============================================================
// Administração (super administrador do site)
// ============================================================
async function vAdmin() {
  $('#main').innerHTML = '<div class="vazio">Carregando…</div>';
  const [r, acessos] = await Promise.all([api('GET', '/api/admin/resumo'), api('GET', '/api/admin/acessos')]);
  const t = r.totais;
  const card = (k, v) => `<div class="card"><span>${k}</span><b>${v}</b></div>`;
  $('#main').innerHTML = `
    <div class="cards">${card('Escritórios', t.escritorios)}${card('Ativos em 7 dias', t.ativos7d)}${card('Agentes conectados', t.agentes)}${card('Usuários', t.usuarios)}${card('Empresas', t.empresas)}${card('Notas', t.notas.toLocaleString('pt-BR'))}</div>
    <div class="grade" style="flex:1 1 320px"><table><thead><tr><th>Escritório</th><th>E-mail</th><th>Criado</th><th class="num">Usuários</th><th class="num">Empresas</th><th class="num">Notas</th>
      <th>Último acesso</th><th>Agente</th><th>Última sincronização</th><th class="cen">Situação</th></tr></thead><tbody>
      ${r.escritorios.map((e) => `<tr><td><b>${esc(e.nome)}</b></td><td>${esc(e.email || '')}</td><td>${fmtD(e.criado_em)}</td><td class="num">${e.usuarios}</td><td class="num">${e.empresas}</td>
        <td class="num">${(e.notas || 0).toLocaleString('pt-BR')}</td><td>${fmtDH(e.ult_acesso)}</td>
        <td><span class="agente-st ${e.online ? 'on' : 'off'}"><i></i>${e.online ? 'conectado' : e.agente_visto ? fmtDH(e.agente_visto) : 'nunca'}</span></td>
        <td>${fmtDH(e.ult_sync)}${e.com_erro ? ` <span class="pill erro">${e.com_erro} com erro</span>` : ''}</td>
        <td class="cen"><button class="btn" style="height:26px" data-esc="${e.id}" data-at="${e.ativo ? 0 : 1}">${e.ativo ? 'Suspender' : 'Reativar'}</button></td></tr>`).join('')}
      </tbody></table></div>
    <div class="secao" style="margin:4px 0 0">Últimos acessos</div>
    <div class="grade" style="flex:0 1 240px;min-height:160px"><table><thead><tr><th>Quando</th><th>Usuário</th><th>Escritório</th><th>IP</th><th>Navegador</th></tr></thead><tbody>
      ${acessos.map((a) => `<tr><td>${fmtDH(a.quando)}</td><td>${esc(a.nome || '')} <span class="dica">${esc(a.login || '')}</span></td><td>${esc(a.escritorio || '')}</td><td class="mono">${esc(a.ip || '')}</td><td title="${esc(a.navegador)}">${esc((a.navegador || '').slice(0, 60))}</td></tr>`).join('')}
    </tbody></table></div>
    <div class="dica">Banco de dados: ${(t.tamanho / 1048576).toFixed(1)} MB.</div>`;
  $$('[data-esc]').forEach((b) => (b.onclick = () => confirmar(b.dataset.at === '1' ? 'Reativar escritório?' : 'Suspender escritório?',
    b.dataset.at === '1' ? 'Os usuários voltam a entrar e o agente volta a sincronizar.' : 'Os usuários desse escritório não conseguem entrar e o agente para de sincronizar. Os dados ficam guardados.',
    b.dataset.at === '1' ? 'Reativar' : 'Suspender', tenta(async () => { await api('PUT', '/api/admin/escritorios/' + b.dataset.esc, { ativo: b.dataset.at === '1' }); vAdmin(); }))));
}

async function auditoria(el) {
  const l = await api('GET', '/api/auditoria');
  el.innerHTML = l.length ? `<table class="hist">${l.map((a) => `<tr><td style="white-space:nowrap">${fmtDH(a.quando)}</td><td>${esc(a.usuario)}</td><td>${esc(a.acao)}</td><td class="mono" style="word-break:break-all">${esc(a.detalhe).slice(0, 300)}</td></tr>`).join('')}</table>` : '<div class="dica">Nada registrado.</div>';
}

// ---------- início ----------
iniciar().catch((e) => { $('#app').innerHTML = `<div class="vazio">Não foi possível abrir o sistema: ${esc(e.message)}<br><br>Confira se o servidor está ligado.</div>`; });
