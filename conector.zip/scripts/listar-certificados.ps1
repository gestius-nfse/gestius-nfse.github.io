﻿# Lista os certificados com chave privada das lojas "Pessoal" do usuário e do computador.
# Saída: JSON (UTF-8) lido pelo servidor Node.
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$saida = New-Object System.Collections.ArrayList
foreach ($loja in 'CurrentUser', 'LocalMachine') {
  foreach ($c in (Get-ChildItem ("Cert:\{0}\My" -f $loja))) {
    if (-not $c.HasPrivateKey) { continue }
    [void]$saida.Add([pscustomobject]@{
      loja     = $loja
      thumb    = $c.Thumbprint
      subject  = $c.Subject
      emissor  = $c.GetNameInfo([System.Security.Cryptography.X509Certificates.X509NameType]::SimpleName, $true)
      validade = $c.NotAfter.ToUniversalTime().ToString('o')
    })
  }
}
[Console]::Out.Write((ConvertTo-Json -InputObject @($saida) -Compress -Depth 3))
