#!/usr/bin/env bash
# Instala o Gestius NFS-e (modo site) num servidor Ubuntu 22.04/24.04 (ex.: Oracle Cloud Always Free).
# Uso (dentro da pasta extraída):  sudo bash scripts/instalar-servidor.sh SEU-SUBDOMINIO.duckdns.org TOKEN-DUCKDNS
set -euo pipefail
DOMINIO="${1:-}"; DUCK="${2:-}"
[ "$(id -u)" = 0 ] || { echo "Rode com sudo."; exit 1; }
[ -n "$DOMINIO" ] || { echo "Uso: sudo bash scripts/instalar-servidor.sh SEU-SUBDOMINIO.duckdns.org [TOKEN-DUCKDNS]"; exit 1; }
ORIGEM="$(cd "$(dirname "$0")/.." && pwd)"
APP=/opt/gestius-nfse; DADOS=/var/lib/gestius-nfse

echo "== 1/6 Pacotes do sistema"
apt-get update -y
apt-get install -y curl ca-certificates gnupg debian-keyring debian-archive-keyring apt-transport-https iptables-persistent

echo "== 2/6 Node.js 22"
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
node -v

echo "== 3/6 Caddy (HTTPS automático)"
if ! command -v caddy >/dev/null; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y && apt-get install -y caddy
fi

echo "== 4/6 Aplicação"
id gestius >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin gestius
mkdir -p "$APP" "$DADOS"
cp -r "$ORIGEM"/lib "$ORIGEM"/public "$ORIGEM"/scripts "$ORIGEM"/server.js "$ORIGEM"/package.json "$APP"/
for f in iniciar-agente.bat LEIA-ME-AGENTE.txt; do [ -f "$ORIGEM/$f" ] && cp "$ORIGEM/$f" "$APP/"; done
cd "$APP" && npm install --omit=dev --no-audit --no-fund --loglevel=error
chown -R gestius:gestius "$APP" "$DADOS"; chmod 700 "$DADOS"

cat > /etc/systemd/system/gestius-nfse.service <<UNIT
[Unit]
Description=Gestius NFS-e (site)
After=network-online.target
[Service]
User=gestius
WorkingDirectory=$APP
Environment=MODO=nuvem PORT=3000 HOST=127.0.0.1 DADOS_DIR=$DADOS NODE_ENV=production
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=3
NoNewPrivileges=true
ProtectSystem=full
ReadWritePaths=$DADOS
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload && systemctl enable --now gestius-nfse

echo "== 5/6 HTTPS em $DOMINIO"
cat > /etc/caddy/Caddyfile <<CADDY
$DOMINIO {
  encode gzip
  reverse_proxy 127.0.0.1:3000 {
    flush_interval -1
    transport http {
      read_timeout 120s
    }
  }
  header {
    Strict-Transport-Security "max-age=31536000"
    X-Content-Type-Options nosniff
    Referrer-Policy no-referrer
  }
  request_body {
    max_size 50MB
  }
}
CADDY
# imagens Ubuntu da Oracle bloqueiam 80/443 no firewall interno
iptables -C INPUT -p tcp --dport 80 -j ACCEPT 2>/dev/null || iptables -I INPUT 5 -p tcp --dport 80 -j ACCEPT
iptables -C INPUT -p tcp --dport 443 -j ACCEPT 2>/dev/null || iptables -I INPUT 5 -p tcp --dport 443 -j ACCEPT
netfilter-persistent save
systemctl restart caddy

echo "== 6/6 DuckDNS"
if [ -n "$DUCK" ]; then
  SUB="${DOMINIO%%.duckdns.org}"
  echo "*/5 * * * * root curl -fsS 'https://www.duckdns.org/update?domains=$SUB&token=$DUCK&ip=' >/dev/null 2>&1" > /etc/cron.d/duckdns
  curl -fsS "https://www.duckdns.org/update?domains=$SUB&token=$DUCK&ip=" && echo " (DuckDNS atualizado)"
fi

echo
sleep 2
echo "Pronto. Abra https://$DOMINIO e crie o seu usuário de administrador do site."
[ -f "$DADOS/codigo-inicial.txt" ] && echo "CÓDIGO DE INSTALAÇÃO (pedido no primeiro acesso): $(cat $DADOS/codigo-inicial.txt)"
echo "Logs: journalctl -u gestius-nfse -f    Banco e cópias: $DADOS"
