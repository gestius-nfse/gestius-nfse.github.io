﻿# Abre o túnel do Cloudflare para o site local e mostra o endereço público.
param([int]$Porta = 3000, [string]$Dados = '')
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = 'Gestius NFS-e - Tunel Cloudflare'
$exe = (Get-Command cloudflared -ErrorAction SilentlyContinue).Source
if (-not $exe) {
  foreach ($c in @("$env:ProgramFiles\cloudflared\cloudflared.exe", "${env:ProgramFiles(x86)}\cloudflared\cloudflared.exe", "$env:LOCALAPPDATA\Microsoft\WinGet\Links\cloudflared.exe")) {
    if (Test-Path $c) { $exe = $c; break }
  }
}
if (-not $exe) { Write-Host 'cloudflared nao encontrado. Rode: winget install --id Cloudflare.cloudflared'; Read-Host 'Enter para sair'; exit 1 }
if (-not $Dados) { $Dados = Join-Path (Split-Path $PSScriptRoot -Parent) 'dados' }
New-Item -ItemType Directory -Force -Path $Dados | Out-Null
$log = Join-Path $Dados 'tunel.log'
$arqUrl = Join-Path $Dados 'endereco-publico.txt'
Remove-Item $log, $arqUrl -ErrorAction SilentlyContinue

while ($true) {
  Write-Host "Abrindo o tunel para http://localhost:$Porta ..."
  $p = Start-Process -FilePath $exe -ArgumentList @('tunnel', '--no-autoupdate', '--url', "http://localhost:$Porta", '--logfile', $log) -PassThru -WindowStyle Hidden
  $url = $null
  for ($i = 0; $i -lt 60 -and -not $url; $i++) {
    Start-Sleep -Seconds 1
    if (Test-Path $log) {
      $m = Select-String -Path $log -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' -AllMatches | Select-Object -Last 1
      if ($m) { $url = $m.Matches[-1].Value }
    }
  }
  if ($url) {
    Set-Content -Path $arqUrl -Value $url -Encoding UTF8
    Write-Host ''
    Write-Host '=============================================================='
    Write-Host '  ENDERECO DO SITE NA INTERNET:'
    Write-Host "  $url" -ForegroundColor Yellow
    Write-Host '  (muda quando o computador ou o tunel reiniciam)'
    Write-Host '=============================================================='
    Write-Host 'Deixe esta janela aberta. Para fechar o site para a internet, feche esta janela.'
  } else { Write-Host 'Nao foi possivel obter o endereco. Confira a internet. Tentando de novo...' }
  Wait-Process -Id $p.Id
  Write-Host 'O tunel caiu. Reabrindo em 5 segundos...'
  Remove-Item $log, $arqUrl -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 5
}
