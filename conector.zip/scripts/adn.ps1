﻿# Chamada ao ADN com certificado da loja do Windows (funciona mesmo com chave NÃO exportável).
#   Modo get : uma requisição; imprime "RESP <http> <base64 do corpo>"
#   Modo dfe : percorre a distribuição por NSU; imprime "LOTE <http> <base64>" por lote e "FIM" no final
param(
  [Parameter(Mandatory = $true)][string]$Thumb,
  [Parameter(Mandatory = $true)][string]$Url,
  [string]$Modo = 'get',
  [string]$Cnpj = '',
  [long]$Nsu = 0,
  [int]$MaxLotes = 200,
  [int]$PausaMs = 300
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Saida([string]$linha) { [Console]::Out.WriteLine($linha); [Console]::Out.Flush() }

try {
  $cert = $null
  if ($env:NFSE_TESTE_PFX) {
    # apenas para testes automatizados fora do Windows
    $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($env:NFSE_TESTE_PFX, $env:NFSE_TESTE_SENHA)
  }
  if (-not $cert) { foreach ($loja in 'CurrentUser', 'LocalMachine') {
    $c = Get-Item -Path ("Cert:\{0}\My\{1}" -f $loja, $Thumb) -ErrorAction SilentlyContinue
    if ($c) { $cert = $c; break }
  } }
  if (-not $cert) { Saida 'ERRO Certificado não encontrado na loja do Windows.'; exit 2 }

  function Chamar([string]$u) {
    for ($t = 1; $t -le 4; $t++) {
      $req = [Net.HttpWebRequest]::Create($u)
      $req.Method = 'GET'
      $req.Accept = 'application/json, application/pdf, */*'
      $req.Timeout = 90000
      $req.ReadWriteTimeout = 90000
      [void]$req.ClientCertificates.Add($cert)
      $resp = $null
      try { $resp = $req.GetResponse() }
      catch {
        $we = $_.Exception
        while ($we -and -not ($we -is [Net.WebException])) { $we = $we.InnerException }
        if ($we -and $we.Response) { $resp = $we.Response }
        elseif ($t -lt 4) { Start-Sleep -Seconds ([math]::Pow(2, $t)); continue }
        else { throw }
      }
      $code = [int]$resp.StatusCode
      $ms = New-Object IO.MemoryStream
      $resp.GetResponseStream().CopyTo($ms)
      $resp.Close()
      # limite de consumo (429) ou instabilidade (5xx): espera e tenta de novo
      if (($code -eq 429 -or $code -ge 500) -and $t -lt 4) { Start-Sleep -Seconds ([math]::Pow(2, $t + 1)); continue }
      return [pscustomobject]@{ Code = $code; Body = $ms.ToArray() }
    }
  }

  if ($Modo -eq 'get') {
    $r = Chamar $Url
    Saida ('RESP {0} {1}' -f $r.Code, [Convert]::ToBase64String($r.Body))
    exit 0
  }

  $lotes = 0
  while ($lotes -lt $MaxLotes) {
    # e-CPF: o ADN recusa o cnpjConsulta (E2243); a consulta vai sem ele
    if ($Cnpj -match '^\d{14}$') { $u = '{0}/contribuintes/DFe/{1}?cnpjConsulta={2}&lote=true' -f $Url, $Nsu, $Cnpj }
    else { $u = '{0}/contribuintes/DFe/{1}?lote=true' -f $Url, $Nsu }
    $r = Chamar $u
    $lotes++
    Saida ('LOTE {0} {1}' -f $r.Code, [Convert]::ToBase64String($r.Body))
    $texto = [Text.Encoding]::UTF8.GetString($r.Body)
    $nsus = @([regex]::Matches($texto, '"NSU"\s*:\s*(\d+)', 'IgnoreCase') | ForEach-Object { [long]$_.Groups[1].Value })
    if ($nsus.Count -eq 0) { break }
    $max = ($nsus | Measure-Object -Maximum).Maximum
    if ($max -le $Nsu) { break }
    $Nsu = [long]$max
    Start-Sleep -Milliseconds $PausaMs
  }
  Saida 'FIM'
}
catch {
  Saida ('ERRO ' + ($_.Exception.Message -replace '\s+', ' '))
  exit 1
}
